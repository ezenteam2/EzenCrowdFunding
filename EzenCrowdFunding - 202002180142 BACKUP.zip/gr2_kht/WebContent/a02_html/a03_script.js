function call2(obj) {
	alert("외부파일호출");
	obj.style.color = "navy";
	obj.style.backgroundColor = "yellow";
	obj.innerHTML = "외부파일 호출 성공!!";
}