/**
 * 
 */

function start3(obj) {
	//alert("또 또 왔냐?");
	obj.style.Color = "#DA70D6";
	obj.innerHTML = "TWIT";
}

function start4(obj){
	//alert("흑우냐?");
	obj.style.Color = "#c8c8c8";
	obj.innerHTML = "TWIT";
	}
