package javaexp.a01_start;

public class A05_DataType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
# 데이터 타입
1. primitive data type
   1) 기본 데이터 유형! 메모리 기준 stack영역에 데이터가 직접 할당 되는 데이터
   2) 종류
        - 정수형 : byte < char < short < int(정수형의 default data type) < long
        - 실수형 : float < double(실수형의 default data type)
        - 논리형 : boolean ( true, false )
        
      
 */
		
		byte num01 = 31; // -128 ~ 127, 8bit(=1byte) 표현 가능
		char char01 = 'Z'; // 1개의 문자를 할당하는 데이터 타입
		int code01 = (int)char01; //각 문자는 유니코드값을 가지고 있다.
		System.out.println("문자 : " + char01);
		System.out.println("코드값 : " + code01); //문자"A"의 유니코드값은 65
		int code02 = 97;
		char char02 = (char)code02;
		System.out.println("코드값 : " + code02);
		System.out.println("문자 : " + char02); //77의 유니코드값은 문자"N"
		
		long num02 = 2433333L; //정수형 int와 구분하기 위해 가장 마지막에 L을 사용
		float float01 = 45.75F; // 4byte이하의 실수를 float으로 할당하는 경우 마지막에 F를 사용
		double dbl01 = 703888; //실수형 default 데이터 타입
		
		boolean isPass = true;
		int passPt = 60;
		int pt = 70;
		boolean isGo = passPt < pt;
		System.out.println("논리값1 : " + isPass);
		System.out.println("논리값2 : " + isGo);
	

/*
2. 형변환 처리
	1) 자동 형변환(promote) : 작은 데이터 타입에서 큰 데이터로 할당할 경우, 별도의 코드가 필요 없이 자동으로 할당 됨
	2) 강제 형변환(casting) : 큰 데이터 타입에서 작은 데이터 타입으로 할당하는 경우, 데이터의 유실이 발생하고, 작은 데이터 형식으로 casting하는 과정이 필요함
 */
		
		//promote
		int num05 = 25;
		double num06 = 30.5 + num05;
		
		//casting
		double num07 = 50.7;
		int num08 = (int)num07;
		System.out.println("promote 후 결과값 : " + num06);
		System.out.println("casting 후 결과값 : " + num08);
	}

}
