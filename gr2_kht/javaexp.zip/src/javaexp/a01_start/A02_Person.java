package javaexp.a01_start;
// javaexp.a01_start;.A02_Person
public class A02_Person {
	public String abc = "gusxo";
	public int agee = 18;

}
