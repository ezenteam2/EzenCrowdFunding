package javaexp.a01_start;


/*
A01_Hello.java
지정한 class 폴더에 저장하는 순간 eclipse tool에서
자동으로 기계가 인식할 수 있는 기계어인 A01_Hello.class
파일을 만들어준다.
실제 실행 파일은 A01_hello.class로 실해오디는데,
해당 파일에 main() 메서드가 있어야 한다.
java A01_hello 
 */

public class A01_Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("하이여");

	}

}
