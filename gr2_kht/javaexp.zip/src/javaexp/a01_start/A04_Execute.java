package javaexp.a01_start;

public class A04_Execute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int apple = 10;
		int banana = 152;
		int fruit = apple + banana;
		System.out.println("apple " + apple);
		System.out.println("banana " + banana);
		System.out.println("fruit " + fruit);

	}

}
