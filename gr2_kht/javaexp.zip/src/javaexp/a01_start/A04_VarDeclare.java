package javaexp.a01_start;

public class A04_VarDeclare {

	int publicVariable01 = 30;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
#변수명 선언 규칙
1. 변수명은 특수문자를 사용하지 않아야 한다. 닽, "$", "_"는 사용가능
2. 변수의 첫 글자를 숫자로 선언할 수 없으나, 나머지에는 사용할 수 있음
3. 자바의 예약어 (if, break, for, continue etc.)를 변수로 선언할 수 없음 -> 그런 경우 숫자를 뒤에 붙여서 사용
 */

		int num01;
//		String name#;      -> 오류 발생
		String $name; //문자열 변수 선언
		double num_dbl; //실수형 변수 선언
//		String 10num;      -> 오류 발생 (숫자를 변수의 첫글자로 사용할 수 음슴)
		int num88_gogo; //변수의 첫 글자만 숫자가 아니면 되고, "_"도 사용 가능
//		int if;            -> 오류 발생 (예약어 if)
//		String for;        -> 오류 발생 (에약어 for)|
		int if01; int for99; int while33; //자바의 에약어를 변수를 사용하는 경우 숫자를 더해서 변수를 선언
		int age = 3;
		int Age = 5;
		System.out.println("age : " + age + " , " + "Age : " + Age); //변수는 대소문자를 구분함
		String setName; //변수의 첫 글자는 소문자, 합성어는 구분되는 첫자를 대문자로 선언해주는 것이 관례
		//중급이상 개발이 복잡해지는 경우, 변수와 주석문을 얼마나 효율적으로 활용하는 지에 따라 프로그램의 가독성이 달라짐
/*
# 리터럴이란?
변수에 저장 된 초기 데이터값을 리터럴이라고 부름 (ex)정수 리터럴, 실수 리터럴, 문자 리터럴, 문자열 리터럴)
 */
		
/*
#변수 사용 범위
1. 전역 변수 (field variable) (line 5)
클래스 바로 아래에 선언, 클래스를 통해서 생성된 객체의 모든 영역에서 불러 올 수 있는 변수 (Field라는 개념으로 활용)

2. 지역 변수(local variable)
조건문 if{}블럭, 반복문 for{}블럭, 중괄호({}), 메서드 내에 선언하여, 클래스 내에 있는 해당 조건문, 반복문, 매서드에서만 불러 올 수 있는 변수
 */
	}

}
