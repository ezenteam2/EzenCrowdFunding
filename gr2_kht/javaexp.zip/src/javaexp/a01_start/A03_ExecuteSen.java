package javaexp.a01_start;

public class A03_ExecuteSen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
# 실행문과 세미콜론(;)
1. 실행문
변수 선언(line 12), 값 저장(line 13), 메소드 호출(line 14)에 해당하는 코드
실행문 끝에는 반드시 세미콜론(;)을 붙여 실행문의 끝이라는 것을 표시한다.
 */
		int a01; //정수형 변수 a01을 선언
		a01 = 39; //변수 a01에 39 값을 저장한다
		System.out.println(a01); //변수 a01을 메서드 System.out.println()로 출력한다.
		
		int a02 = 10; //정수형 변수 a02의 선언과 할당을 동시에
		int a03 = a01 + a02; //변수 a03에 앞에서 선언한 변수를 연산
		System.out.println(a02);
		System.out.println("합은 " + a03); //결과물 출력
		
		//ex) A04_Execute.java를 클래스로 만들고,
		//사과의 갯수를 변수로 선언과 할당,
		//바나나의 갯수를 변수로 선언과 할당.
		//두개의 변수를 합쳐서 fruit로 만들고, 출력처리
	}

}
