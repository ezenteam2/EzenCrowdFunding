package javaexp.a04_object;

public class B04_Constructor {

/*

# 생성자
	1. new 연산자에 의해 호출되어 객체의 초기화를 담당
		1) 필드의 값 설정 ex) this.date = date;
		2) 일단 생성되면 참조변수로 여러 멤버를 사용할 수 있게 함
	
	2. 생성자 오버로딩
		1) 오버로딩이란 	- 생성자나 메서드가 같은 클래스에서 동일한 이름으로 선언할 수 있는 기준
						- 선언 기준 (갯수, type, 순서)	
							- 매개 변수의 갯수가 다를 때 (매개 변수의 갯수가 다르면 다른 생성자로 인식)
 							- 매개 변수의 갯수가 같더라도 type이 다른 경우
 						
 	3. 생성자 this
 		1) 생성자 this란	- 생성자나 메서드에서 this.필드명 현재 객체의 전역 멤버를 가르킬 때 사용,
 		2) this.필드명, this.메서드()
 		3)	- this.(입력값(매개변수)) : 현재 class에서 선언한 매개변수가 다른 생성자에 데이터를 전달하여 호출
 		 	- this(매개값)을 통해 선언된 생성자를 호출
 		 			cf)	super()	: 상속관계에 있을 때, 상위 클래스의 생성자를 지칭
 		 				this()	: 상속관계에 있을 때, 현재 클래스의 생성자
 		
*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//ChristMas cm1 = new ChristMas();
		
		//사용자 정의 생성자가 매개변수로 선언되면, default 생성자는 사라짐
		
		ChristMas cm2 = new ChristMas("2019년 12월 25일");
		System.out.println("멤버의 접근 cm2.date : " + cm2.date);
		System.out.println("메서드 호출 cm2.show()");
		cm2.show();
		ChristMas cm3 = new ChristMas();
		ChristMas cm4 = new ChristMas(25);
		ChristMas cm5 = new ChristMas("2019년 12월 25일", 25);
		ChristMas cm6 = new ChristMas(25, "2019년 12월 25일");

/* ex) Member01 클래스 선언,
		속성 default, id할당, id와 이름 할당, id와 숫자 비밀번호 할당 하여 overloading으로 생성자 선언할 것
	
 */
		Member01 mem1 = new Member01();
		Member01 mem2 = new Member01("Peace B");
		Member01 mem3 = new Member01("Peace C", "CoA");
		Member01 mem4 = new Member01("Peace D", 12341234);
	
	
	}

}

class Member01 {

	String id;
	String name;
	int password;
	
	public Member01() {
		System.out.println("속성 default값 출력");
	}
	
	public Member01(String id) {
		//this.id = id;
		System.out.println("id 할당 : " + id);
	}
	
	public Member01(String id, String name) {
		//this.id = id;
		//this.name = name;
		System.out.print("ID 할당 : " + id + "\t\t");
		System.out.println("이름 할당 : " + name);
	}
	
	public Member01(String id, int password) {
		//this.id = id;
		//this.password = password;
		System.out.print("ID 할당 : " + id + "\t\t");
		System.out.println("숫자 비밀번호 : 안알랴줌");
	}
	
	public Member01(String id, String name, int password) {
									// this(매개값)을 통해 선언된 생성자를 호출하므로
		//this.(id, name);			// 중복하여 id, name을 할당할 필요 없음
		//this.password = password;
		System.out.print("ID 할당 : " + id + "\t\t");
		System.out.println("숫자 비밀번호 : 안알랴줌");
	}
	
}

class ChristMas {
	String date;
	String origin;
	//default 생성자는 자동으로 선언 됨
	//public ChristMas();
	
	// 사용자 정의 생산자
	
	public ChristMas(String date) {
		this.date = date;
		System.out.println("생성자 호출.(입력값1) - 문자열");
	}
		
	public ChristMas() {
		System.out.println("생성자 호출.(입력값1)");
	}
	// 오버로딩 - 매개 변수 갯수가 외와 차이가 남
	
	public ChristMas (int num) {
		System.out.println("생성자 호출.(입력값1) - 숫자");
	}
	// 오버로딩 - 매개 변수의 데이터 type이 위와 다름
		
	public ChristMas (int num, String s) {
		System.out.println("생성자 호출.(입력값2 - 숫자, 문자열)");
	}
	
	public ChristMas (String s, int num) {
		System.out.println("생성자 호출.(입력값2 - 문자열, 숫자)");
	}
	// 오버로딩 - 두 생성자의 매개 변수의 순서가 다름
	
	public void show() {
		System.out.println("크리스 마스는 " + date + "입니다!");
	}
	
	public void show(String s) {
		System.out.println("크리스 마스는 " + date + "입니다!");
	}
}
