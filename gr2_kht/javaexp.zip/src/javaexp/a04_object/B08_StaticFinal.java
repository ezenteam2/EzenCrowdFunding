package javaexp.a04_object;

class Person2{
	String name1;
	final String NAME2;
	static final String NAME3="홍길동(static final";
	
	Person2(String name){
		this.name1=name;
		this.NAME2=name;
//		this.NAME3=name; static final은 객체 단위로 할당할
//		수 없음.
	}
	
	
}
class Fruit{}
public class B08_StaticFinal {
	/*
# 클래스 상수(static final)
1. final는 상수로 변경되지 않는 필드를 의미하며,
class 단위 필드인 static를 붙이면 클래스 상수로 
사용된다.
2. final 상수는 대문자로 명명하는 것이 관례이다.
3. 합성어의 경우 단어_단어 로 구분하여 선언한다.

	*/	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
1. 일반 field는 객체 단위로 데이터를 할당 변경할 수 있다.
		 * */
		Person2 p1 = new Person2("홍길동(p1)");
		System.out.println("변경 전(p1.name1):"+p1.name1);
		System.out.println("변경 전(p1.NAME2):"+p1.NAME2);
		// final 필드 이더라도 객체단위로 다른 변수를 할당 수
		// 있다.
		p1.name1="오길동";
//		P1.NAME1="마길동";  해당 필드는 final이기 대문에
//		변경이 불가하다.
		System.out.println("변경 후(p1.name1):"+p1.name1);
		
		Person2 p2 = new Person2("김길동(p2)");
		System.out.println("변경 전(p2.name1):"+p2.name1);
		System.out.println("변경 전(p2.NAME2):"+p2.NAME2);
		p2.name1="진길동";
		System.out.println("변경 후(p2):"+p2.name1);		
		// static final은 클래스 상수로 한번 클래스에서
		// 초기화 되면, 할당 및 변경이 불가능 하다.
		/*
		ex) Fruit 클래스 선언하여 price1, PRICE2, PRICE3
		으로 일반변수, 상수, static final로 선언하여,
		데이터 할당 변경에 대한 객체와 관계 속에 범위를 설정하세요.
		
		 * */
		Fruit01 f01 = new Fruit01(5000);
		// 변경 가능..
		f01.price1 = 3000;
		// 상수라 변경 불가.
//		f01.PRICE2 = 6000;
//		// 객체 단위로 생성할 수도 없고 변경도 불가능.. 
//		Fruit01.PRICE3 = 9000;
		Fruit01 f02 = new Fruit01(7000);
		System.out.println("# final만 붙으면 객체 단위 초기화 가능 #");
		System.out.println("f01의 PRICE2"+f01.PRICE2);
		System.out.println("f02의 PRICE2"+f02.PRICE2);
	}
}
class Fruit01{
	int price1;
	final int PRICE2;
	static final int PRICE3=3000;
	Fruit01(int price){
		price1 = price;
		PRICE2 = price;
	}
}



