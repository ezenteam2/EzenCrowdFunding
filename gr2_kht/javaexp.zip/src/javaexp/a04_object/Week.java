package javaexp.a04_object;

/*
# 열거 타입 (Enumeration type)
	1. 한정된 값만을 갖는 데이터 타입
	2. 한정된 값을 열거 상수로 정의
	3. 선언 및 생성
		1)	파일 이름과 동일한 이름을 선언\
			public enum 열거타입이름
		2)	한정된 값인 열거 상수 정의
				*관례상
				- 열거 상수 이름은 대문자로 작성
				- 합성어인 경우, "_"로 연결 
 */

public enum Week {		//열거 타입 이름
	MONDAY,				// 열거 상수
	TUESDAY,
	WEDNESDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY

}
