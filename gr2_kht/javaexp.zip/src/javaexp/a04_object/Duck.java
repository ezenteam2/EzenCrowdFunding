package javaexp.a04_object;

public class Duck {
	private String kind;
	private String color;
	public Duck() {
		
	}

}
