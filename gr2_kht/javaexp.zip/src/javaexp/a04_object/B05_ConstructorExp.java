package javaexp.a04_object;

public class B05_ConstructorExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
