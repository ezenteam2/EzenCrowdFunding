package javaexp.a04_object;

public enum CarMove {
	RIGHT,
	LEFT,
	FORWARD,
	REVERSE
	
}
