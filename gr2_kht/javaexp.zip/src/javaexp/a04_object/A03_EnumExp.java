package javaexp.a04_object;

import java.util.Scanner;

public class A03_EnumExp {

/*
# 열거 타입의 활용
1. 열거 타입 변수 선언
	1) 열거타입 변수
		ex) Week today;
	2) 열거 상수 값 저장
		열거타입 변수 = 열거타입.열거상수
		ex) Week today = Week.SUNDAY;
	3) 열거 타입 변수 초기화
		ex) Week birthday = null;
2. 열거 객체의 메소드 활용
	1) 열거 객체는 열거 상수의 문자열을 내부 데이터로 가짐
	2) 사용 메서드
		name() : 열거 객체의 문자열을 리턴
		ordinal() : 열거 객체의 순번(0부터 시작)을 리턴
		compareTo() : 열거 객체를 비교하여 순번 차이를 리턴
		valueOf(String name) : 주어진 문자열의 열거 객체를 리턴
		values() : 모든 열거 객체들을 배열로 리턴
 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Week tomorrow = null;
		tomorrow = Week.MONDAY;
		Week birthday = Week.FRIDAY;
		Week today = Week.SUNDAY;
		System.out.println(today);
		System.out.println(birthday);
		System.out.println(tomorrow);
		tomorrow = Week.SUNDAY;
		System.out.println(tomorrow);
	
		System.out.println();
		
		Week choDay = today.SUNDAY;
		String name = choDay.name();
		System.out.println("선택한 요일 : " + name);
		int ordinal = choDay.ordinal();
		System.out.println("선택한 요일의 INDEX : " + ordinal);
		int result1 = Week.MONDAY.compareTo(Week.THURSDAY);
		System.out.println("compareTo를 통한 비교 : " + result1);
		
		System.out.println();
		
		//ex) 	자동차의 움직임(오른쪽, 왼쪽, 직진, 후진)을 열거타입 CarMove라고 선언
		//		main 메서드에서 열거형 초기화 왼쪽과 직진을 출력
		
		CarMove move = null;
		move = CarMove.LEFT;
		System.out.println("어디로 가야하죠? : " + move);
		move = CarMove.FORWARD;
		System.out.println("어디로 가야하죠? : " + move);

		//ex)의 메서드를 이용하면
		//특정한 방향명, index, 왼쪽과 뒤로의 차이 index를
		CarMove direction = CarMove.FORWARD;
		int ordinal01 = direction.ordinal();
		int result02 = CarMove.LEFT.compareTo(CarMove.REVERSE);
		System.out.println("직진의 INDEX : " + ordinal01);
		System.out.println("compareTo를 통한 비교 : " + result02);
 
		
		System.out.println();
		
		// values()는 배열을 가져온다
		Week [] days = Week.values();
		for (Week day : days) {
		
		}
		for ( int idx = 0; idx < days.length; idx++) {
			System.out.println("day[" + idx +"] : " + days[idx]);
		}
		
		// 문자열로 enum의 방향을 입력 받아, enum을 선택하고
		// 입력 받은 방향에 따라 진행 방향을 출력
		
		System.out.println();
		
		Scanner sc = new Scanner(System.in);
/*			System.out.print("방향을 입력 하세요 (직진F, 후진B, 오른쪽R, 왼쪽L) : ");
		String dir = sc.nextLine();
		CarMove move01 = null;
		
		if ( dir.equals("F") ) {
			move01 = CarMove.FORWARD;
			System.out.println(move01 + "을/를 선택하셨습니다");
			System.out.println("직진!!!!");
		} else if ( dir.equals("B") ) {
			move01 = CarMove.REVERSE;
			System.out.println(move01 + "을/를 선택하셨습니다");
			System.out.println("후진!!!!");
		} else if ( dir.equals("R") ) {
			move01 = CarMove.RIGHT;
			System.out.println(move01 + "을/를 선택하셨습니다");
			System.out.println("우측으로!!!!");
		} else if ( dir.equals("L") ) {
			move01 = CarMove.LEFT;
			System.out.println(move01 + "을/를 선택하셨습니다");
			System.out.println("좌측으로!!!!!!!");
		} else {
			System.out.println("잘못 입력하셨습니다");
		}
*/		
		while( true ) {
			System.out.print("방향을 입력 하세요 (직진F, 후진B, 오른쪽R, 왼쪽L) : ");
			String dir = sc.nextLine();
			CarMove cm = CarMove.valueOf(dir);
			if ( cm == CarMove.LEFT ) System.out.println("왼쪽으로"); 
			else if ( cm == CarMove.RIGHT ) System.out.println("오른쪽으로"); 
			else if ( cm == CarMove.FORWARD ) System.out.println("직진"); 
			else if ( cm == CarMove.REVERSE ) System.out.println("뒤로"); 
			else break;
		}
		System.out.println("스토오오오옵!!");
	}
		
}
