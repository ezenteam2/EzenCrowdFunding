package javaexp.a04_object;

import java.util.Scanner;

public class A01_Reference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num01 = 25;								// 기본 타입 변수
		ObjectTarget ob01 = new ObjectTarget();		// 객체 타입 참조 변수
		
		System.out.println("# stack 메모리 데이터 # 들어있는 데이터는 무엇?");
		System.out.println("num01 : " + num01);
		System.out.println("ob01 : " + ob01); 		// 출력값 : javaexp.a04_object.ObjectTarget@15db9742
													// 객체명@16진수로된 heap 영역의 주소
													// 객체는 참조변수를 통해서 heap영역의 특정한 주소에 할당된 객체를 찾아간 후
													// 소속되어 있는 속성(field)명으로 접근하여 확인  => 참조변수.속성명
		System.out.println("ob01.num01 : " + ob01.num01);
		
		ObjectTarget ob02 = new ObjectTarget();
		System.out.println("ob02 : " + ob02);
		System.out.println("ob01 vs ob02 = ? " + (ob01 == ob02));
													// 같은 내용의 객체를 다른 참조 변수로 선언하면
													// ==의 불린값은 false
													// 주소값은 다르게 지정 되는 것
	

/* 
 # 변수의 메모리 사용
	1. 기본 타입 변수 - 실제 값을 변수 안에 직접 저장 (stack)
	2. 참조 타입 변수 - heap영역의 객체의 주소를 가지고 있고, heap 영역에 실제 데이터가 저장되어 있다

# null
	heap 영역에 객체를 생성하지 않고, stack영역에 메모리만 선언한 상태를 null초기화라고 한다.
		ex)	ob01, ob02는 new라는 키워드를 사용해 객체를 생성한다.
			초기화 시에는 클래스명 참조변수명 = null;라고 선언한다.
			객체에 데이터 없이 선언만 하면, 초기값으로 null이 지정 된다. (실제 존재하지 않는 데이터임)
			주소값 확인시, null

# nullPointerException
	1. pointer라는 주소를 가리킴, 위 예외는 주소값이 없을 때, 참조객체의 멤버(객체가 가지고 있는 구성요소)를 사용할 때 나타남 

 */
		ObjectTarget ob03 = null;			//heap영역에 객체를 할당하지 않고, stack영역에 선언만 한 경우
		System.out.println(ob03);			//결과값 : null -> 객체가 생성되지 않음
		System.out.println(ob03 == null);	//결과값 : true
		//System.out.println(ob03.num01);	//결과값 : NullPointerException 발생
											//		-> 	실제 데이터 혹은 객체가 할당되지 않은 상태에서
											//			heap 영역의 특정한 결과값을 불러올 때 발생 
											// NullPointerException을 벗어 나기 위해
		if ( ob03 != null ) { 				// -> 객체가 생성되어 있을 때 명령문 실행! 이라는 조건을 붙여 줌
			System.out.println("ob03 생성 완료");
		}
		if ( ob02 != null ) {
			System.out.println("ob02 생성 완료!");
		}
		
		System.out.println();

/*
#String 문자열의 메모리 할당
1. 	문자열을 직접적으로 대입한 경우, 똑같은 문자열을 여러 변수에  할당하더라도 하나의 heap영역 메모리만 할당하여 여러 주소를 공유한다
	이러한 경우, ==을 통한 주소값 비교시 결과값은 true
	ex)	String name1 = "홍길동";
		String name2 = "홍길동";
		System.out.println(name1 == name2);	=>결과값 : true
*/
		
		String name1 = "홍길동";
		String name2 = "홍길동";
		System.out.println("name1 : " + name1);
		System.out.println("name2 : " + name2);
		System.out.println("name1 == name2 : " + (name1 == name2));

		System.out.println();

/*
2. 	사용자 인터페이스(파일로 로딩, Scanner를 통한 입력)를 사용하여 입력하거나,
	"new"를 사용하여 객체를 생성하는 경우(ex) new String("문자열"))
	같은 문자열일지라도 각각 다른 heap영역의 메모리를 사용하기 때문에
	==을 통한 주소값 비교시 결과값은 false 
	이러한 경우, .equals 메소드를 이용하여 비교해줘야함
*/
	
		String name3 = new String("홍길동");
		String name4 = new String("홍길동");
		System.out.println("name3 : " + name3);
		System.out.println("name4 : " + name4);
		System.out.println("name3 == name4 : " + (name3 == name4));
		System.out.println("name3.equals(name4) : " + (name3.equals(name4)));
		
		System.out.println();

	
		//ex) 주관식 문제를 내고, Scanner에 의해 정답을 입력 받아, 정답! or 오답! 출력
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("\"높곡옾눞\"은 뭘 뜻하는 걸까여? : ");
		String answer = "폭풍눈물";
		String input = sc.nextLine();
		
		
//		do {
		if (input.equals("폭풍눈물")) {
			System.out.println("올킈? 당신은 요즘사람");
//			break;
		} else {
			System.out.println("옛날 사람 이것도 모름?");
			System.out.print("재도전??? (Y/N)");
			String YN = sc.nextLine();
			
			if (YN.equals("N")) {
//				break;
			} else {
				System.out.println("다시 도전하세요");
			}
		}
//		} while (input.equals("폭풍눈물")) { 
	
	}


}


	

class ObjectTarget {
	int num01 = 30;
}