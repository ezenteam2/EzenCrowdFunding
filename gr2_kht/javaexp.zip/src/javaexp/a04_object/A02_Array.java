package javaexp.a04_object;

public class A02_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
# 배열
	1. 같은 타입의 데이터를 연속된 공간에 저장하는 자료 구조
	2. 장점
		1) 여러 데이터를 동일한 변수에 할당할 수 있어 변수 선언을 줄일 수 있다.
			ex)	int num01, num02, num03; ==> int[] num;
		2) 반복문을 이용하여 효과적으로 요소들을 할당, 수정, 호출을 할 수 있다.
			ex)	num01 = (int)Math.random() * 6;
				num02 = (int)Math.random() * 6;
				num03 = (int)Math.random() * 6;
				
				==>>
				for (int idx = 0; idx <num.length; idx++) {
					num[idx] = (int)Math.random() * 6;
				}
	3. 배열의 선언
		1) 데이터type[] 변수명;	or	데이터type 변수명[];
			ex)	int[] score;
				String names[];
		2) 배열 변수는 객체로 생성하기 전에 null로 초기화가 가능하다
			ex)	int score[] = null;
				boolean[] pass = null;
					==>	배열 객체가 생성되지 않은 상태에서 배열명[index번호]로 호출하면
						NullPointerException이 발생
	4. 배열 객체의 생성
		1) 크기만 생성 (값은 비워둠)
			ex) int[] points = new int[5];		=>	*객체는 생성하지만, 구성요소의 값은 할당되지 않은 상황
		2) 값을 초기에 할당하면서 생성
			ex) String[] fruits = {"사과", "바나나, "딸기"};
			
					====>1), 2) 모두 객체를 생성하기 때문에, stack영역과, heap영역 모두를 사용한다.
	5. 활용
		1) 	데이터 할당 - 배열명[index번호] = 데이터값;
			데이터 호출 - 배열명[index번호]
	 	2) 속성 1	- index : 각 데이터 저장 위치는 0부터 시작하는 인덱스로 접근 가능
				ex) String abc [] = {현태, 바동, 가리, 끔디, 시니, 잼괴}
			 		System.out.println(abc[0]); ==> "현태"
			 		System.out.println(abc[1]); ==> "바동"
			 		System.out.println(abc[2]); ==> "가리"
			 		System.out.println(abc[3]); ==> "끔디"
			 		System.out.println(abc[4]); ==> "시니"
			 		System.out.println(abc[5]); ==> "잼괴"
		3) 속성 2	- 배열명.length : 배열의 길이를 가져옴, 배열의 전체 크기를 활용해야할 때 사용, 읽기만 가능
		4) 배열의 index와 배열 길이 length를 반복문과 함께 활용하여 사용 가능
			ex) for ( 배열의 초기 index값 설정; 배열길이보다 -1로 조건설정; index값의 증가) {
				배열명[index값의 변수];를 활용
				}
			ex)	String fruits[] = {"apple", "banana", "strawberry"}
				for (int idx = 0 ; idx < fruits.length; idx++) {
				반복 처리할 내용
				}
			 	
 */

		
		//ex1) 정수형으로 가격을 할당할 배열 선언
		
		int price[] = null;
		
		//ex2) 실수형으로 학생 3명의 키를 할당할 배열 선언 및 생성
		
		double height[] = new double[3];
		
		//ex3) ex2)의 두번재 학생의 키를 할당
		
		height[1] = 180.9;
		
		//ex4) 성인인지의 여부를 나타내는 배열 3개를 선언 및 할당
		
		boolean isAdult[] = {true, false, false};
		
		//ex5) 주사위 3번 던진 값을 배열에 할당하여 출력하세요
		
		int dice[] = new int[100];
		int sum = 0;
		
		for (int no01 = 0; no01 < dice.length; no01++) {
		dice[no01] = (int)(Math.random() * 6 + 1);
		System.out.println((no01 + 1) + "번째 주사위 결과 : " + dice[no01]);
		sum += dice[no01];
		}
		System.out.println("합계 : " + sum);
		double avg = sum / dice.length; 
		System.out.println("평균 : " + avg);
		
/*
# 다차원 배열
	1. 2차원 이상의 배열을 처리할 때 활용 (배열 안의 배열)
	
	2. 형식  ( [][][] 차원의 갯수만큼 선언 )
 			- 데이터type [][] 배열명 = new 데이터type [크기1][크기2];
		1) [][][] : 차원의 갯수만큼 선언 - 3차원
		2) 크기1 : 최상위 차원의 배열의 크기
		3) 크기2 : 하위 차원의 배열의 크기
	3. 활용법
		1) 데이터 할당 	- 배열명[1차원의 index 번호][2차원의 index 번호] = 데이터
		2) 데이터 호출 	- 배열명[1차원의 index 번호][2차원의 index 번호];
		3) 데이터 선언 및 할당
					- 데이터type 배열명 [][] = { {데이터1, 데이터2}, {데이터1, 데이터2} };
		4) 하위 배열의 경우, 각 배열마다 길이가 다른 배열도 가능
					- 데이터type 배열명 [][] = { {데이터1}, {데이터1, 데이터2}, {데이터1, 데이터2, 데이터3} };
	
 */

		/*
		//ex) 7호차 까지 있는 기차, 각 호차마다 60개의 좌석이 있는 경우
		//		1차원 - 7칸, 2차원 - 60개
		int train01[][] = new int[7][60];
		//		1호차 1번 좌석에 앉은 사람 번호를 1으로 할당 처리
		train01[0][0] = 1;
		System.out.println("default 데이터 확인 : " + trains [0][1]);
		
		//ex1)	5차, 각 호차마다 50칸 있는 배열을 선언 후, 2번째칸 5번째 좌석에 임의의 번호를 할당
		
		int train02[][] = new int[5][50];
		train02[1][4] = (int)(Math.random() * 10 + 1);
		System.out.println("2번째칸 5번째 좌석 할당 번호 :" + train02[1][4]);
		
		//ex2) 	고등학교 3개 학년, 5개 반에 ##학년 ##반 담이 : @@, 3학년 2반 담임 홍길동을 할당
		
		String homeRoomT[][] = new String[3][5];
		homeRoomT[2][1] = "홍길동";
		System.out.println(homeRoomT[2][1]);
		*/
		//ex3)	학급수 5개, 한 학급당 35명의 영어성적을 2차원 배열로 배열 선언 및 데이터 할당
		System.out.println();
		
		int engScore[][] = new int[5][35];
		int sum01[] = new int[5];
		double avg01[] = new double[5];
		
		for ( int studentno = 0; studentno < engScore[0].length; studentno++) {
			System.out.print("\t" + (studentno + 1) + "번");
		}

		System.out.println();	
		
		for ( int classno = 0; classno < engScore.length; classno++ ) {
			System.out.print((classno + 1) + "반 : \t");
			
			for ( int studentno = 0; studentno < engScore[classno].length; studentno++ ) {
				
				engScore[classno][studentno] = (int)(Math.random() * 100 + 1);
				System.out.print(engScore[classno][studentno] + "\t");
				sum01[classno] += engScore[classno][studentno];
		
				//engScore.length : 최상의 배열의 크기
				//engScore[0].length : 1번째 배열의 크기 
				
			}
			avg01[classno] = sum01[classno] / 35;
			System.out.println();
		}
		System.out.println();
		
		for ( int classno = 0; classno < 5; classno++ ) {
			System.out.println("##" + (classno + 1) + "반 \t 총점 : " + sum01[classno] + "\t 평균 : " + avg01[classno]);
		}
		
		System.out.println();
		
		String[][] prods = { {"사과", "딸기", "키위"},
							 {"바나나"},
							 {"멜론", "수박", "자몽", "망고스틴"} };
		
		
	}

}
