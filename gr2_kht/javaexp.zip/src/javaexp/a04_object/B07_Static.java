package javaexp.a04_object;

class Bear{
	int eatCnt;
	static int totCnt;
	String name;
	Bear(String name) {
		this.name = name;
	}
	void eat() {
		System.out.println(name + " 곰돌이가 " + (++eatCnt) + "개 빵을 먹었다");
		System.out.println("현재 곰돌이들이 먹은 빵의 갯수 : " + (++totCnt) + "개");
	}	
}

public class B07_Static {

/*
# instance 필드 / 변수		- 클래스가 선언된 후, 객체가 생성될 때, 객체마다 다르게 처리 되는 변수
# static 필드 / 변수		- 여러 객체가 생성이 되더라도, class 단위로 특정데이터를 저장/처리할 때 사용되는 변수
 */


	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bear b1 = new Bear("첫 번째 곰돌이 ");
		Bear b2 = new Bear("두 번째 곰돌이 ");
		Bear b3 = new Bear("세 번째 곰돌이 ");
		b1.eat();
		b1.eat();
		b2.eat();
		b2.eat();
		b3.eat();
		b3.eat();

	}


}