package javaexp.a04_object;

public class A02_Array2 {

	
/*
# 배열의 복사
	1. 배열은 한번 만들어지면 구조를 변경할 수 없음
		- 크기가 3인 배열을 선언했다면, 4이상으로 변경할 수 없음
		- 기존 배열을 기준으로 배열의 크기를 변경하는 경우, 새로운 배열을 만들고 기존 배열의 데이터를 할당한 후, 추가 데이터를 처리
		- JAVA에서는 한 번 정해진 배열의 구조는 변경하지 못함 => 이를 위해서는 동적 배열로서 새로운 배열을 만들어야 함
	2. 배열의 구조를 변경하는 복사 방법
		1) for 이용
		2) System.arraycopy( 기존배열, 시작index, 새로운배열, 시작index, 기존배열의 크기 )
		
# 배열을 위한 향상된 for
	1. 	for ( 단위 데이터 : 배열 ) {
			단위 데이터를 할당 / 호출
		}
	2.	String[] fruits = {"APPLE", "BANANA", "STRAWBERRY"};
		String fruit = fruits[0];
		for (String fruit : fruits) {
		}
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num01Array [] = {90, 80, 70};	//기존 배열
		int num02Array [] = new int [5];	//새로운 배열
		
		for ( int idx = 0; idx < num01Array.length; idx++ ) {
			num02Array[idx] = num01Array[idx];
		}									//새로운 배열에 기존 배열을 넣고
		
		num02Array[3] = 80;
		num02Array[4] = 65;					//새로운 데이터를 새로운 배열에 추가
		
		System.out.println("배열 num02Array 내용");
		for ( int idx = 0; idx < num02Array.length; idx++ ) {
			System.out.println("num02Array[" + idx + "] : " + num02Array[idx]);
		}
		
		System.out.println();
		
		//2) System.arraycopy( 기존배열, 시작index, 새로운배열, 시작index, 기존배열의 크기 )
		
		int num03Array[] = new int[5];		//{0, 0, 90, 80, 70}
		//	System.arraycopy(	기존배열,		시작index,	새로운배열,	시작index,	기존배열의 크기 )
			System.arraycopy(	num01Array, 0,			num03Array,	1, 			3);
		
		for ( int idx = 0; idx < num03Array.length; idx++ ) {
			System.out.println("num03Array[" + idx + "] : " + num03Array[idx]);
		}
		
		//ex1) 	사과 바나나 딸기 배열과, 크기 5개짜리의 빈 배열을 만들어 기존의 배열을 새로운 배열에 복사하고,
		//		오렌지 수박을 추가
		
		System.out.println();
		
		String fruit01[] = {"APPLE", "BANANA", "STRAWBERRY"};
		String fruit02[] = new String[5];
		String fruit03[] = {"ORANGE", "WATERMELON"};
		
		System.arraycopy(fruit01, 0, fruit02, 0, 3);
		/*
		for ( int idx = 0; idx < fruit01.length; idx++ ) {
			fruit02[idx] = fruit01[idx]; 
		}
		*/
		
		for ( int idx = 0; idx < fruit03.length; idx++ ) {
			fruit02[idx + fruit01.length] = fruit03[idx];
		}
		
		for ( int idx = 0; idx < fruit02.length; idx++ ) {
			System.out.println("fruit02[" + idx + "] : " + fruit02[idx]);
		}
		
		System.out.println();
		
		String movies[] = {"FROZEN", "Mt.Baekdoo", "ASKING TO GOD"};
		
		System.out.println("# 향상된 for 활용 #");
		for (String movie01 : movies) {
			System.out.println(movie01);
		}
		
		System.out.println();
		
		String CELEBs[] = {"한예슬", "수애", "산다라박"};
		
		System.out.println("# 향상된 for 연예인 #");
		for (String CELEB : CELEBs) {
			System.out.println(CELEB);
		}
		
	}

	}

