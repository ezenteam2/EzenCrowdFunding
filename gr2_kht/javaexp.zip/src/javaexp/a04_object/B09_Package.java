package javaexp.a04_object;

/*
# package
1. 클래스를 선언하는 최상위에 선언하여, 소속되어 있는
계층구조하의 위치를 지정한다.
2. 일반적으로 같은 package에 있으면, 객체 생성시, 
패키지명을 생략이 가능하다.
3. 다른 패키지에 있는 클래스를 호출할 때, 조건.
	1) 접근제어자가 class, 생성자 모두 public
	2) 이 때, 패키지명.클래스명  참조 = new 패키지명.클래스명()
	   사용한다. - 클래스명는 패키지명을 포함하는 개념이다.
	3) 다른 패키지에 있는 클래스는 import를 이용하면,
	   패키지 선언은 생략이 가능하다.
	   패키지명 @@@
	  import 사용할외부패키지클래스
	 4) 패키지명이 다른 동일한 클래스 어떻게 사용하는지?
	 	- 클래스명이 동일한 경우, 같은 메모리 영역에서
	 	사용할려면 import해서 사용할 수 없다.
	 	- 패키지명전체를 호출하여 사용하여, 구분하여야 한다.
	 	
 * */
import javaexp.a03_controller.A02_Condition;
public class B09_Package {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B02_Person b02 = new B02_Person();
		javaexp.a03_controller.A08_DoubleLoop 
		con = new javaexp.a03_controller.A08_DoubleLoop();
		A02_Condition  con2 =new A02_Condition();
	}

}
