package javaexp.a04_object;

public class B03_Field {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Car c1 = new Car("현대", "빨강", "그랜져");
		c1.speedUp(5);
		c1.speedUp(15);
		c1.speedUp(20);;
		System.out.println("현재 속도 : " + c1.speed);
		System.out.println("회사 : " + c1.company);
		System.out.println("차량 색상 : " + c1.color);
		System.out.println();
		
		c1.setTire(new Tire("금호"), 0);
		c1.setTire(new Tire("금호"), 1);
		c1.setTire(new Tire("한국"), 2);
		c1.setTire(new Tire("한국"), 3);
		System.out.println("타이어 : ");
		for(Tire t: c1.arT1) {
			System.out.println(t.kind);
		}
		
		
		System.out.println();
		
		Bank b1 = new Bank("국민");
		b1.saving(100000000);
		b1.saving(20000000);
		b1.saving(4500000);

	}

}
/*
# 필드 (field)
	1. 객체의 고유 데이터 	(ex) 제작회사, 모델, 색깔, 최고속도 etc.)
	2. 상태 				(ex) 현재속도, 엔진회전수 etc.)
	3. 포함할 다른 객체 		(ex) 엔진, 타이어 etc.)

# 필드의 선언 방법
	1. 데이터type 필드명;
		- 생성자를 통한 초기화 (*가장 많이 쓰이는 방식)
		- 메서드를 통한 데이터 할당/변경
	2. 데이터type 필드명 = 초기데이터;
*/

	//객체가 될 클래스 선언
class Car {
	
	//필드 선언
	String company;
	String color;
	String model;
	
	int speed;
	int rpm;
	
	String classtype = "Car";
	Tire[] arT1;	//객체를 배열로 선언하는 것도 가능
	Engine eg;
	
	// Car c1 = new Car("현대", "노랑", "그랜져);
	Car(String company, String color, String model) {
		this.company = company;
		this.color = color;
		this.model = model;
		arT1 = new Tire[4];
	}
	
	void setTire(Tire add, int idx) {
		arT1[idx] = add;
	}
	
	
	
	// c1.speedUp(10);	speedUp이라는 해당 메서드를 이용하여 입력받은 파라미터가 누적처리됨
	// c1.speedUp(20);
	// c1.speedUp(20);	결과값 : 50
	void speedUp( int addSpeed ) {
		//매개변수에 입력받은 값을 누적처리
		this.speed += addSpeed;
	}
	
}
	
class Tire {
	
	String kind;	//타이어 이름
	
	Tire (String kind) {
		this.kind = kind;
	}

}

class Engine {
	
	String name;
	
}

	// Bank 클래스에 field로 은행명, 총입금액 
	// 생성자를 통해서 은행명
	// saving()메서드의 매개변수 int addMoney를 통해서
	// 총입금액 누적처리

class Bank {
	
	String bankName;
	int deposit;
	
	Bank ( String bankName ) {
		this.bankName = bankName;
		System.out.println("은행 이름은 : " + bankName);
	}
	
	void saving (int addMoney) {
		System.out.println(bankName + " 은행 입금 금액 : " + addMoney);
		this.deposit += addMoney;
	}
}