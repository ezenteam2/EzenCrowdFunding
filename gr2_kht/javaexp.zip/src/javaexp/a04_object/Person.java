// 1. 패키지 : 어디에 소속되어 있는지?
package javaexp.a04_object;


//	1. 프로그램의 설계도!!!!

public class Person {		//필드 선언

	// 2. 접근제어자 class 클래스명{ }	(**public - 아무나 접근하세요)
	/*
		1) 클래스 이름 선언 규칙
			- 한개 이상의 문자
			- 이름의 첫머리에 숫자는 불가
			- 특수문자는 "#", "_"만 허용
			- 자바의 키워드는 사용할 수 없음
			- 대소분자 구분
		2) 관례상
			- 한글 이름도 가능하나 영어로 작성
			- 클래스인 경우, 첫글자는 대문자
			- 합성어를 지정하는 경우, 연결하는 첫분자는 대문자로 작성
	 */
	
	// 1. 파일명과 동일한 class명 1개만 public으로 설정 가능하고,
	// 2. 추가 class는 public을 선언하지 못한다.
	// 3. 	Person.java
	//		javac Person.java
	//		Person.class, Woman22.class, Man22.class 파일이 컴파일시에 생성됨
	// 4. 한 package안에 동일한 이름의 class명을 생성할 수 없음
	String name;
	
	// 생성자를 생성해 놓지 않아도, default 생성자를 내부적으로 선언됨
	// public Person() {}

}

class Woman22{}


class Man22{}
