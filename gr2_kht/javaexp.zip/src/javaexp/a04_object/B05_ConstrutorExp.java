package javaexp.a04_object;

public class B05_ConstrutorExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
