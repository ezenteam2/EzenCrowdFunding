package javaexp.a04_object;


public class B01_Class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 선언된 클래스는 main()메서드를 통해 메모리를 만들고 
		// 호출할 때 객체를 만들어 사용한다
		
/*		객체 만들기
		1. 클래스명 참조변수 = new 생성자();
		하나의 선언된 클래스에서 여러 객체를 다른 heap영역에서 만들어 쓸 수 있음
		
*/		
		
										//Person이라는 설계도로
		Person p1 = new Person();		//p1이라는 지역에 건물을 짓고		//p1인 경우 : instance p1
		Person p2 = new Person();		//p2라는 지역에 건물을 지음		//p2인 경우 : instance p2
		System.out.println(p1);			
		System.out.println(p2);			
		p1.name = "홍길동";				//p1이라는 지역에 Person이라는 설계도로 지어진 건물에는 "홍길동"이라는 사람이 들어감
		p2.name = "신길동";				//p2라는 지역에 Person이라는 설계도로 지어진 건물에는 "신길동"이라는 사람이 들어감
		
		//ex) 	Entertainer 클래스 선언
		//		해당 클래스의 field로 name
		//		연예인 3개 객체를 생성
		//		이름 지정
		
		Entertainer x1 = new Entertainer();
		Entertainer x2 = new Entertainer();
		Entertainer x3 = new Entertainer();
		System.out.println(x1);
		System.out.println(x2);
		System.out.println(x3);
		x1.name = "산다라박";
		x2.name = "한예슬";
		x3.name = "수애";
		System.out.println(x1.name);
		System.out.println(x2.name);
		System.out.println(x3.name);
		
/*
# 객체의 메모리 할당
	1. 	메서드 new를 이용하여(ex) new Person();), heap 영역에 class를 사용하기 위한 메모리를 할당하여 객체를 생성하고,
	 	해당 heap영역의 주소값을 return
		이를 저장하는 변수를 instance 변수 / reference 변수라고 한다.
	2. instance 변수는 클래스명 ins변수로 선언
 */
		System.out.println("객체 생성 : " + new Person());
		Person p3 = new Person();	//default 생성자 호출
		
		// 1. 생성자 선언한 객체 생성
		B02_Person B02_1 = new B02_Person();
		
		// 2. field 사용
		B02_1.name = "홍길동";
		System.out.println(B02_1.name);
		
		// 3. 메서드 사용
		B02_1.call();
		

		System.out.println();
		
		//ex1) Computer 클래스 선언, 생성자로 컴퓨터 생성됨! 출력
		//속성 kind(컴퓨터 종류) 메서드 operate() 컴퓨터 작동 출력
		
		Computer c1 = new Computer();
		
		c1.kind = "노트북";
		
		c1.operate();
		
		Computer c2 = new Computer("삼성센스");
		c2.operate();
		
		System.out.println();
		
		//ex2) 	Member 클래스 선언, 필드로 id를 선언
		//		생성자로 문자열을 받아서 id값에 할당
		//		메서드로 longin()으로 현재 로그인한 id는 @@@ 출력

		Member m1 = new Member();
		m1.login();
		
		System.out.println();
		
		Member m2 = new Member("김현태");
		m2.login();

		
	}

}

