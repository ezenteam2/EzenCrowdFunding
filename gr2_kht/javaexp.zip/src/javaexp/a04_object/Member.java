package javaexp.a04_object;

import java.util.Scanner;

public class Member {

	String id;
	
	
	
	Member () {
		Scanner sc = new Scanner(System.in);
		System.out.print("ID를 입력하세요 : ");
		String id01 = sc.nextLine();
		this.id = id01;
	}
	
	Member (String id) {
		this.id = id;
	}
	
	void login() {
		System.out.println("Login한 ID는 : " + id + "입니다");
	}
	
}
