package javaexp.a04_object;

import java.util.Scanner;

public class A03_Enum {
/*
# 열거 타입의 활용
1. 열거 타입 변수 선언.
    1) 열거타입 변수
        ex) Week today; 
    2) 열거 상수 값 저장.
                열거타입 변수 = 열거타입.열거상수
        ex) Week today = Week.SUNDAY;
    3) 열거 타입 변수 초기화
        ex) Week birthday = null;
2. 열거 객체의 메소드 활용
    1) 열거 객체는 열거 상수의 문자열을 내부 데이터로 가지고 있다.        
    2) 사용 메서드
        name() : 열거 객체의 문자열을 리턴..
                                 선언된 열거상수를 문자열로 가져오는 처리.
        ordinal() : 열거 객체의 순번(0부터 시작)을 리턴.
                0,1,2...열거객체의길이-1
        compareTo() : 열거 객체를 비교해서 순번 차이를 리턴..
        valueOf(String name) : 주어진 문자열의 열거 객체를 리턴.
                         열거 타입의 변수를 선언하고, valuesOf("문자열") 해당하는 열거 객체를 가져오는 처리..
        values() : 모든 열거 객체들을 배열로 리턴..
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Week today = null;
		today = Week.TUESDAY;
		System.out.println(today);
		System.out.println("데이터1:"+today);
		Week choDay = today.SUNDAY;
		String name = choDay.name();
		System.out.println("선택한 요일:"+name);
		int ordinal = choDay.ordinal();
		System.out.println("선택한 요일의 index:"+ordinal);
		int result1 = Week.MONDAY.compareTo(Week.THURSDAY);
		System.out.println("compareTo를 통한 비교:"+result1);
		// 특정 문자열을 통해서 enum객체를 선택할 때, 활용된다.
		Week weekDay = Week.valueOf("SUNDAY");
		if( weekDay == Week.SUNDAY || weekDay == Week.SATURDAY) {
			System.out.println("주말을 선택했습니다.");
		}else {
			System.out.println("평일을 선택했습니다.");
		}
		// values()은 배열을 가져온다.
		Week [] days = Week.values();
		for(Week day : days) {
			System.out.println(day);
		}
	
		//자동차의 움직임을 열거타입으로 CarMove라고 선언하고,
		//열거상수로 오른쪽, 왼쪽, 직진, 후진으로 선언 후,
		//main메서드에서 열거형 초기화 왼쪽과 직진을 출력 처리하세요.
		// 선언은 영문으로 처리하세요.
		
		CarMove carLeft = null;
		CarMove carGo = null;
		
		carLeft = CarMove.LEFT;
		carGo = CarMove.GO;
		
		System.out.println(carLeft);
		System.out.println(carGo);
		System.out.println();
/*
      위 메서드를 이용해서,
      특정한 방향명, index, 왼쪽과 뒤로의 차이 index를 출력 		
 */
		String leftName = carLeft.name();
		int LeftOrdinal = carLeft.ordinal();
		System.out.println("방향명:"+leftName);
		System.out.println("leftName의 방향명 :"+LeftOrdinal);
		int result01 = CarMove.LEFT.compareTo(CarMove.BACK);
		System.out.println("왼쪽과 뒤로의 차이 :"+result01);
/*  ex) 문자열로 enum의 방향을 입력받아서..해당, enum을 선택하고,
 *     조건문으로 방향에 따라서, 차가 앞으로 갑니다.
 *     뒤로 갑니다. 왼쪽을 방향으로 변경했습니다. 오른쪽으로 방향을 변경했습니다를 처리하여 출력하세요
		
 */
/*
        Week weekDay = Week.valueOf("SUNDAY");
		if( weekDay == Week.SUNDAY || weekDay == Week.SATURDAY) {
			System.out.println("주말을 선택했습니다.");
		}else {
			System.out.println("평일을 선택했습니다.");
		}
		// values()은 배열을 가져온다.
		Week [] days = Week.values();
		for(Week day : days) {
		    // .name()과 같이 해당 열거 상수를 향상된
		    // for문에 의해서 데이터를 가져 온다.
			System.out.println(day);
		}		
 */
		
/*		Scanner sc = new Scanner(System.in);
		System.out.println("방향을 입력하세요. 우회전(0), 좌회전(1), 직진(2), 후진(3) 숫자로 입력 : ");
		int into = sc.nextInt(); 
	
		CarMove carRight = null;
		CarMove carBack = null;
		
		carRight = CarMove.RIGHT;
		carBack = CarMove.BACK;
		
		int RightOrdinal = carRight.ordinal();
		int GoOrdinal = carGo.ordinal();
		int BackOrdinal = carBack.ordinal();
		
		if( into == LeftOrdinal) {
			System.out.println("왼쪽으로 방향을 변경했습니다.");
		}else if( into == RightOrdinal) {
			System.out.println("오른쪽으로 방향을 변경했습니다.");
		}else if( into == GoOrdinal) {
			System.out.println("차가 앞으로 갑니다.");
		}else if( into == BackOrdinal) {
			System.out.println("차가 뒤로 갑니다.");
		}else {
			System.out.println("잘못 입력되었습니다.");
		}
*/
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.print("방향 입력하세요(LEFT/RIGHT/FORWARD/BACKWARD/BREAK):");
			String dir = sc.nextLine();
			CarMove cm = CarMove.valueOf(dir);
			if( cm == CarMove.LEFT ) System.out.println("왼쪽을 방향을 변경했습니다.");
			else if( cm == CarMove.RIGHT ) System.out.println("오른쪽을 방향을 변경했습니다.");
			else if( cm == CarMove.GO ) System.out.println("차가 앞으로 갑니다.");
			else if( cm == CarMove.BACK ) System.out.println("차가 뒤로 갑니다.");
			else break;
		}
		System.out.println("자동차가 멈추었습니다!!");
		

	}

}
