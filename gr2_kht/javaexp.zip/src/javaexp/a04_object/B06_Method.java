package javaexp.a04_object;



/*
# Method
	1. 메소드란?	- 객체의 동작(기능)을 처리하는 기능 함수
	2. 중괄호{} 블록 안에 호출해서 실행할 수 있는 코드들  
	3. 메소드를 호출하면 중괄호{} 블록에 있는 모든 코드 들이 일괄 실행
	4. 선언의 기본 형식
		1) Return 타입 메서드 -	메서드이름(매개변수1, 매개변수2) {
								처리할 내용
								return 리턴 타입에 따라 할당할 유형의 데이터;
							}
						ex)	int plus (int num01, int 02) {
							 return num01 + num02;
							}
							- 리턴 타입은 기본 primitive 데이터 유형, 객체 유형, 배열
		2) Return 값이 없는 경우 -	void 메서드이름() {
		 							처리할 내용
		 						}
	5. 메서드 오버로딩 - 메소드 매개변수의 갯수, type, 순서가 같지 않으면, 동일한 이름의 메서드가 하나의 클래스 안에서 선언 가능
		 						
ex1) class calculator에 정수, 실수값을 입력 받아, 소숫점이라 나눗셈 처리하여 실수값을 리턴하는 메서드
ex2) 숫자 2개를 입력 받아 @@ * @@ = @@ 라는 문자열을 리턴하는 메서드 선언
ex3) 숫자 1개를 입력 받아 10000이상인지 여부에 따른 boolean값 리턴하는 메서드
ex4) id, pass 입력받아 himan / 777이면 로그인 성공, 실패하면 로그인 실패 문자열 return
*/

public class B06_Method {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Calculator c1 = new Calculator();
		System.out.println("c1.plus(25, 30) : " + c1.plus(25, 30));
		c1.show();
		//String x = c1.show(); 	// 오류발생 : 리턴값이 없는 메서드이므로
		
		System.out.println("c1.plus(234234, 123132112) : " + c1.plus(234234, 123132112));
		System.out.println("c1.divide(12312412, 123.12) : " + c1.divide(12312412, 1231231));
		System.out.print("c1.printNum(1234, 5678) : ");	c1.printNum(1234, 5678); 
		System.out.println("c1.bigNum(1923847) : " + c1.bigNum(1923847));
		System.out.println("c1.login(\"himan\", \"777\") : " + c1.login("himan", "777"));
		System.out.println("c1.login(\"alskdjf\", \"sldkfjsl\") : " + c1.login("alskdjf", "sldkfjsl"));
	}

}

class Calculator{
	
	int plus(int num01, int num02) {
		return num01 + num02;
	}
	
	int plus(int num01) {
		// this.plus(num01, 0) : 현재 객체의 메서드 plus()에 데이터 num01을 전달
		return this.plus(num01, 0);
	}
	
	double divide (int num01, double num02) {
		return num01 / num02;
	}
	
	void printNum (int num01, int num02) {
		System.out.println(num01 + " * " + num02 + " = " + (num01 * num02));
	}
	
	boolean bigNum(int num01) {
		return num01 > 10000;
	}
	
	String login (String id, String password) {
		/*
		if (id == "himan" && password == "777") {
			return "로그인 성공";
		} else {
			return "로그인 실패여 똥멍청이";
		}
		*/
		String ret = id.equals("himan") && password.equals("777") ? "로그인 성공" : "로그인 실패 똥멍청이";
		return ret;
	}
	
	void show() {
		System.out.println("void show() : 리턴값 없이 출력만 하시오");
	}
}