package javaexp.a04_object;

public class Computer {
		String kind;
		
		Computer() {
			System.out.println("Class Computer 생성 완료!!");
		}
		
		Computer(String kind) {
			// 매개변수로 받은 데이터를 this : 현재 객체의
			// this.kind : 현재 객체가 가지고 있는 멤버중, kind를 지칭
			this.kind = kind;
			System.out.println(kind + " 컴퓨터 생성 완료!!!!!");
		}
			
		void operate() {
			System.out.println(kind + " 컴퓨터 작동!!!");
		}
	
}