package javaexp.a04_object;

public class Entertainer {

	public String name;
	
}

