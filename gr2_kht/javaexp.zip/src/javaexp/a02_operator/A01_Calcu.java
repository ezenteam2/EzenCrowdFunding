package javaexp.a02_operator;

public class A01_Calcu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
#연산
1. 연산 : 데이터를 처리하여 결과를 산출하는 과정
	ex) int num05 = 25 + 30;
2. 연산자(operations)
	연산에 사용되는 표시나 기호
	ex) +, -, *, /, %, =, !=, >=, etc.
3. 피연산자(oprands) : 연산 대상이 되는 데이터
	ex) int num06 = 30 + num05;			=> 30, num05가 피연산자
4. 연산식 : 연산자와 피연산자를 이용하여 연산의 과정을 기술
	ex) boolean isPass = point >= 60;	=> 변수 point, 리터럴 상수 60, 비교연산자 >=를 사용하여 비교 연산식을 구성
 */

		
		// 예제1) 곰돌이 3마리가 빵 3, 5, 7개를 각가 가지고 있다. 총 방의 갯수를 연산식으로 만들어 보시오.
		int bearBread1 = 3;
		int bearBread2 = 5;
		int bearBread3 = 7;
		int bearBreadSum = bearBread1 + bearBread2 + bearBread3;
		System.out.println("곰돌이 빵 총 개수 : " + bearBreadSum);
		// 예제2) 쇼핑몰에서 30000원짜리 액세서리를 5개 구매하였다. 총 비용을 연산식으로 코드화 하시오.
		int accPrice = 30000;
		int accNum = 5;
		int shopPrice = accPrice * accNum;
		System.out.println("쇼핑 가격 : " + shopPrice);
		// 예제3) 친구 5명이 함께 음식점에 들려, 총 비용이 100000원이 나왔다. 각자 계산할 비용은?
		int foodPrice = 100000;
		int pplNum = 5;
		int payment = foodPrice / pplNum;
		System.out.println("지불 가격 : " + payment);

/*
#산술 연산자
1. 종류 : +, -, *, /, %	
*/
		int bearCnt = 3;
		int breadTotCnt = 10;
		int restBread = breadTotCnt % bearCnt;
		System.out.println(restBread);
		
/*
2. 부호 연산자 : 특정 변수에 부호(+, -)를 붙여 부호를 변경
 */
		int num05 = 300;
		int num06 = -num05;
		int num07 = -50;
		int num08 = -num07;
		int num09 = +num05;
		System.out.println("num05 음의부호 : " + num06);
		System.out.println("num07 음의부호 : " + num08);
		System.out.println("num05 양의부호 : " + num09);
		
		// 예제4) 은행 계좌에 초기 금액 1000000원, 매월 500000원씩 입금, 매월 300000씩 생활비로 출금
		// 부호 연산자를 사용하여 코드화 하시오
		
		int balance = 1000000;
		int saving = +500000;
		int withdraw = -300000;
		int rest = balance;
		
		//입금처리
		rest = rest + saving;
		System.out.println("입금 1 : " + rest);
		rest = rest + saving;
		System.out.println("입금 2 : " + rest);
		rest = rest + saving;
		System.out.println("입금 3 : " + rest);
		
		//출금처리
		rest = rest + withdraw;
		System.out.println("출금 1 : " + rest);
		rest = rest + withdraw;
		System.out.println("출금 2 : " + rest);
		rest = rest + withdraw;
		System.out.println("출금 3 : " + rest);
		
/*
# 문자열에서 연산자 "+"
1. 문자열을 이어주는 역할
2. 숫자와 함께 사용되는 경우 숫자도 문자열로 인식
3. 숫자 + 숫자 + "문자열"의 경우 숫자끼리 연산한 후 문자열에 이어줌
4. "숫자형문자열" + "숫자형문자열"의 경우 숫자를 문자로 인식(숫자로서의 연산 불가)
				=> 연산을 위해서는 숫자형으로 변환하는 메서드를 이용해야 함
					1)정수형 : Integer.parseInt("정수형문자열")
					2)실수형 : Double.parseDouble("실수형문자열")
 */
		
		//sysout + ctrl + space : System.out.println() 로딩
		//ctrl + alt + 화살표 아래 : 해당 라인 복사
		System.out.println(25 + 30 + "앙뇽");
		System.out.println("50" + "70");
		System.out.println(Integer.parseInt("50") + Integer.parseInt("70"));
		double num01 = Double.parseDouble("50.8");
		double num02 = Double.parseDouble("70.8");
		System.out.println(num01 + num02);
		//외부에서 사용자 인터페이스를 통해 입력되는 데이터값은 대부분 문자열로 처리 됨. 문자로 처리된 입력값을 숫자로 처리하기 위해서는 위의 전환 과정이 필요함
		
		//예제5) 생년을 문자열로 데이터를 선언, 올해를 숫자로 변수를 선언한 후, 만나이를 형변환에 의해 출력
		String birthYear = "1988";
		int thisYear = 2019;
		int age = thisYear - Integer.parseInt(birthYear);
		System.out.println("만 나이 : " + age);
		//System.out.println("만 나이 : " + thisYear - Integer.parseInt(birthYear));		=>>>> 왜 오류남?????


	}

}
