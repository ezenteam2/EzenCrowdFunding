package javaexp.a02_operator;

public class A03_EqualCalcu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*
# 비교 연산자
1. 두 개의 데이터나 변수를 비교하여 해당 값에 대한 논리값(true, false)을 가져오는 연산자
	조건문과 반복문에서 해당 블럭({})을 처리할 기준으로 사용
2. 연산자 종류 (==, >, <, >=, <=, <>) *부정의 의미로 "!"를 붙임
	1) a == b : 변수 a, b의 stack영역에 있는 데이터가 동일할 때 true
	2) a != b : 변수 a, b의 stack영역에 있는 데이터가 동일하지 않을 때 true
	3) a (>, <, >=, <=) b : 변수 a, b의 stack영역에 있는 데이터중 a가 b보다 크거나, 작거나, 크거나 같거나, 작거나 같은 경우에 대한 boolean값
3. 논리 연산자 - 비교 연산자를 이용하여 만든 연산식을 2개 이상 활용하는 경우 	ex) 획득 점수가 80점 이상, 90점 미만인 경우 학점 "B"를 출력!
	1) && (and) : 두개의 연산자 모두를 충족시켜야 true			ex) ID, Password 입력시, 두 값 모두 만족해야 로그인 가능!
	2) || (or) : 둘 중 하나의 연산자만 만족해도 true
	3) ! + 연산자 (not) : 결과 boolean 값의 반대 boolean 값으로 처리
			60이상이면 패스
			boolean isPass = score01 >= 60;
			boolean isNotPass = !score01 >= 60;
			isNotPass = !isPass
 4. 조건 삼항 연산자
 	1) 조건식에 따라 결과값을 return해주는 연산자 (논리 연산자는 true/false 두 값 중 하나만 결과값으로 취할 수 있지만, 삼항 연산자에서는 취사 선택 가능)
 	2) (조건식)? true일 때 처리할 데이터 : false일 때 처리할 데이터
 			ex) pt >= 60? "합격" : "불합격"	=> 데이터가 조건을 만족할 때, 결과값을 선택적으로 가져옴
 */
		
		int num01 = 30;
		int num02 = 30;
		int num03 = 40;
		System.out.println("num01 == num02 : " + (num01 == num02));
		System.out.println("num01 != num02 : " + (num01 != num02));
		System.out.println("num01 = num03 : " + (num01 = num03));		 //*주의! 이 경우는 "=" 대입연산자로 쓰이는거 
		System.out.println(num01); 
		
		if(num01 == num02) {
			System.out.println("빙고");
		} else {
			System.out.println("똥멍청아");
		}
	
		//ex1) 4지 선다형 문제를 냈을 때, 정답 여부를 논리값으로 가져 오시오
		//		(if문을 이용, 정답인 경우 "정답", 오답인 경우 "똥멍청이!"를 출력)
		
		int answer = 1;			//정답
		int choice = 100;		//선택한 번호
		System.out.println("정답 여부 : " + (answer == choice));
		if (choice == answer) {
			System.out.println("똑똑한디?");
		} else {
			System.out.println("틀렸다, 똥멍청이!");			
		}
		
		int num04 = 10;
		int num05 = 100;
		System.out.println("num04 > num05" + (num04 > num05));
		System.out.println("num04 < num05" + (num04 < num05));
		System.out.println("num04 <= num05" + (num04 <= num05));
		System.out.println("num04 <= num05" + (num04 <= num05));
		
		//ex2) 획득한 점수가 70점 이상일 때, boolean값 출력
		int score01 = 70;
		System.out.println("점수는 70 이상? :" + (score01 >= 70));
		
		//점수가 80점 이상 90점 미만 일 경우, B
		score01 = 80;
		System.out.println("B학점 여부 : " + (score01 >=80 && score01 <90));
		
		//점수가 100 초과, 0 미만인 경우 유효한 점수가 아닙니다
		score01 = 75;
		System.out.println("점수 유효 여부 : " + (score01 > 100 || score01 < 0));
		if(score01 < 0 || score01 > 100) {
			System.out.println("점수는 0과 100 사이로 입력하셈");
		}
		
		//ex3) 나이가 20세 이상인 경우 성인을 출력
		int age01 = 30;
		if(age01 >= 20) {
			System.out.println("잠시만여, 손님");
		} else {
			System.out.println("안돼, 돌아가");
		}
		
		//ex5) 나이가 14~20 사이이면 청소년요금제, 4미만이거나, 65이상은 무료
		if (age01 >=14 && age01 <=20) {
			System.out.println("청소년 요금제입니당");
		} else if (age01 < 4 || age01 > 65) {
			System.out.println("무료입자앙");
		} else {
			System.out.println("일반요금이에영");
		}
		
		//삼항 연산자 example
		String result = score01 >= 60 ? "잘해떠여" : "똥멍청아";
		System.out.println(result);
		
		//ex6) 나이가 14~20일 때, 청소년 요금제, 그 외에는 일반요금제
		String PRICE = age01 >=14 && age01 <= 20 ? "쪼렙" : "성숙하시네여";
		System.out.println(PRICE);
	}

}
