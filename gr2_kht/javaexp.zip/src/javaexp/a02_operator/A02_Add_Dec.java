package javaexp.a02_operator;

public class A02_Add_Dec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
#대입 연산자(=)
1. 대입연산자(=)를 사용하여 우항의 데이터를 좌항 변수로 할당함
*/
		int num01 = 30; //30이라는 우항의 데이터를 좌항의 num01변수로 대입

/*
#증감 연산자 (++, --)
1. 1의 값만큼 데이터를 증가시키거나 감소시켜줌
 */
		System.out.println("증감연산자 ++ " + ++num01);
		System.out.println("증감연산자 ++ " + ++num01);
		System.out.println("증감연산자 ++ " + ++num01);
		
/*
*1 이 외의 값만큼 데이터를 증감하는 경우
대입 연산자와 증감 연산자를 같이 사용함 (+=, -=, *=(지수처리), /=)
 */
		num01 = num01 +3;
		System.out.println(num01);
		num01 += 3;
		//두 문장은 같은 문장
		System.out.println(num01);
		System.out.println("3씩 증가 : " + (num01 += 3));
		System.out.println("3씩 증가 : " + (num01 += 3));
		System.out.println("3씩 증가 : " + (num01 += 3));
		System.out.println("2씩 감소 : " + (num01 -= 2));
		System.out.println("2씩 감소 : " + (num01 -= 2));
		System.out.println("2씩 감소 : " + (num01 -= 2));
		
		//ex1) 김밥 1줄당 가격 18000, 증감 연산자를 사용하여 10줄까지의 가격을 출력하세용
		int gimBabNum = 0;
		int gimBabPrice = 0;
		System.out.println("김밥" + ++gimBabNum + "줄 : " + (gimBabPrice += 1800));
		System.out.println("김밥" + ++gimBabNum + "줄 : " + (gimBabPrice += 1800));
		System.out.println("김밥" + ++gimBabNum + "줄 : " + (gimBabPrice += 1800));
		System.out.println("김밥" + ++gimBabNum + "줄 : " + (gimBabPrice += 1800));
		System.out.println("김밥" + ++gimBabNum + "줄 : " + (gimBabPrice += 1800));
		System.out.println("김밥" + ++gimBabNum + "줄 : " + (gimBabPrice += 1800));
		System.out.println("김밥" + ++gimBabNum + "줄 : " + (gimBabPrice += 1800));
		System.out.println("김밥" + ++gimBabNum + "줄 : " + (gimBabPrice += 1800));
		System.out.println("김밥" + ++gimBabNum + "줄 : " + (gimBabPrice += 1800));
		System.out.println("김밥" + ++gimBabNum + "줄 : " + (gimBabPrice += 1800));
			
		//ex2) 은행 잔액 1000000, 매일 지출되는 교통비 3600, @@일 현잔액 @@@@원으로 출력하세용 
		int initBalance = 1000000;
		int date = 19;
		System.out.println(++date + "일 잔액" + (initBalance -= 3600) + "원");
		System.out.println(++date + "일 잔액" + (initBalance -= 3600) + "원");
		System.out.println(++date + "일 잔액" + (initBalance -= 3600) + "원");
		System.out.println(++date + "일 잔액" + (initBalance -= 3600) + "원");
		System.out.println(++date + "일 잔액" + (initBalance -= 3600) + "원");
		System.out.println(++date + "일 잔액" + (initBalance -= 3600) + "원");
		System.out.println(++date + "일 잔액" + (initBalance -= 3600) + "원");
		System.out.println(++date + "일 잔액" + (initBalance -= 3600) + "원");
		System.out.println(++date + "일 잔액" + (initBalance -= 3600) + "원");
		System.out.println(++date + "일 잔액" + (initBalance -= 3600) + "원");
		
		int expense = 3600;
		System.out.println(++date + "일 잔액" + (initBalance -= expense) + "원");
		
		//ex3) 1세대가 2명의 자녀를 가지고, 다음 세대마다 2명의 자녀를 가진다고 했을 때, 각 세대별 자녀의 숫자를 출력해보세용
		int gen = 0;
		int firstGen = 1;
		System.out.println(++gen + "세대 :" + (firstGen *= 2) + "명");
		System.out.println(++gen + "세대 :" + (firstGen *= 2) + "명");
		System.out.println(++gen + "세대 :" + (firstGen *= 2) + "명");
		System.out.println(++gen + "세대 :" + (firstGen *= 2) + "명");
		System.out.println(++gen + "세대 :" + (firstGen *= 2) + "명");
		System.out.println(++gen + "세대 :" + (firstGen *= 2) + "명");
		System.out.println(++gen + "세대 :" + (firstGen *= 2) + "명");
		System.out.println(++gen + "세대 :" + (firstGen *= 2) + "명");
		System.out.println(++gen + "세대 :" + (firstGen *= 2) + "명");
		System.out.println(++gen + "세대 :" + (firstGen *= 2) + "명");
		
		int per = 2;
		System.out.println(++gen + "세대 :" + (firstGen *= per) + "명");
		
		
				

	
	}

}
