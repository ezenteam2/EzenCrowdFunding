package javaexp.a02_operator;

public class homework {

	public static void main(String[] args) {
	
		String trs01 = "지하철";
	    String trs02 = "버스";
	    
		int cost01 = 1300;
		int cost02 = 1500;
		
		int total01 = cost01*2;
		int total02 = cost02*2;
		
		System.out.println(trs01+" 총 비용:"+total01);
		System.out.println(trs02+" 총 비용:"+total02);
/*2) 커피샵에서 아메리카노(3000) 2잔, 카페라테(4000)
		3잔을 주문하여, 총비용이 @@@ 원 들었다.
		변수명을 이용하여 프로그래밍 코드를 기술하세요
*/		
		int priceAm = 3000;
		int priceCl = 4000;
		int amCnt = 2;
		int clCnt = 3;
		int total = priceAm*amCnt + priceCl*clCnt;
		System.out.println("총 비용 :"+total);
		
	//	4. + 연산자의 문자열 처리와 숫자 처리에 대한 내용을 예를 통해기술하세요
/*
 1. "문자열1" + "문자열2"는 문자열을 이어 주는 역할을 한다. 
     System.out.println("이젠"+"아카데미"); // 이젠아카데미
     
 2. "문자열" + 숫자 : 앞에 문자열이 있으면 숫자도 문자열로 인식하여
        문자열숫자 형태로 이어져서 처리된다.
        System.out.println("이젠"+10); // 이젠10
 3. 숫자 + 숫자 + "문자열" : 문자열이 시작할 때, 없고 숫자가 나오면 일단 연산한 후에
        문자열을 이어 준다.
        System.out.println(10+20+"번째"); // 30번째
 4. "숫자형문자열" + "숫자형문자열" : 숫자형문자열을 이어 주는 처리
         System.out.println("20"+"10"); // 2010
          연산을 하려면  숫자형으로 변환하는 기능메서드를 이용하여, 처리후에 연산을 한다.   
       1) 정수형으로 변환 : Integer.parseInt("정수형문자열")
       System.out.println(Integer.parseInt("20")+Integer.parseInt("10")); // 30
       2) 실수형으로 변환 : Double.parseDouble("실수형문자열") 
       double nb01 = Double.parseDouble("22.8");
		double nb02 = Double.parseDouble("12.8");
		System.out.println(nb01-nb02); // 10.0 
       
 
 */
		System.out.println("이젠"+"아카데미");
		System.out.println("이젠"+10);
		System.out.println(10+20+"번째");
		System.out.println("20"+"10"); // 2010
		System.out.println(Integer.parseInt("20")+Integer.parseInt("10")); // 30
		
		double nb01 = Double.parseDouble("22.8");
		double nb02 = Double.parseDouble("12.8");
		System.out.println(nb01-nb02); // 10.0 
		
/*
 7. 아래와 같이 매일 식비 6000, 용돈 10000 을 고정 수입 지출금으로 하여,
	대입/증감 연산자를 이용한 가계부 처리를 하세요.
	현잔액(용돈 - 식비)
	1일   식비누적 6000   용돈 10000  현잔액 @@@
	2일   식비누적 12000  용돈 20000  현잔액 @@@
	3일   식비누적 18000  용돈 30000  현잔액 @@@		
 */
		int cost10 = 6000;
		
		/*# 연산자 우선순위
		0. 우선순위의 최상위는 ()
		1. /, * 차상위
		2. +, - 같은 우선
		   /, * 같은 우선 순위
		*/
		//        *,/ 우선 순위
				System.out.println(2+1*3);
				// ()는 최상위 우선 순위
				System.out.println((2+1)*3);
				// 대입 연산자는 왼쪽에서 오른쪽을 할당.
		
				int num01 = 30;
	    int num02;          
	    int num03;          
	    int num04;
	    num04 = num03 = num02 = num01;
	    System.out.println("num01:"+num01);
	    System.out.println("num02:"+num02);
	    System.out.println("num03:"+num03);
	    System.out.println("num04:"+num04);
	}

}
