package javaexp.a02_operator;

public class A04_CalcuDirect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
# 연산자 방향
1. 비교 연산자 & 논리 연산자 & 산술 연산자는 왼쪽에서 오른쪽으로 진행
	//100 * 2 / 3 % 5
	//----------->
2. 대입연산자(=)는 오른쪽에서 왼쪽으로 진행
	//int a = b = c = 6
    //     <-----------

# 연산자 우선순위
	1) ()
	2) /, *
	3) +, -

# 단항 연산자
	피연산자(변수)가 1개
		ex) cnt++, --num01

# 이항 연산자
	피연산자(변수)가 여러개로 연산 결과값을 처리하는 연산자
	산술, 대입, 비교, 논리 연산자
		ex) num01 + num02, "He" + "llo", num01 += 5
*/
		int num01 = 10;
		int num02 = 20;
		int num03;
		int num04;
		num04 = num02 = num03 = num01;
		System.out.println("num01 : " + num01);
		System.out.println("num02 : " + num02);
		System.out.println("num03 : " + num03);
		System.out.println("num04 : " + num04);
		
		System.out.println(2 + 1 * 3);
		//*, / 가 우선
		System.out.println((2 + 1) * 3);
		//()는 *, /보다 우선
	}

}
