package javaexp.a07_object2;

/*
# 클래스 처리 단계
	1. 클래스에서 객체 생성
	2. 클래스 안에 클래스 선으로, 객체 안에 종속된 객체를 호출 처리
		1:1 객체
		- 상속객체
			ex) 컴퓨터와 CPU, 남녀, 
	3. 클래스 안에 배열 클래스 호출로, 객체 안에 종속된 배열형 객체 호출 처리
		ex) 마트와 물건들, 가계부와 수입 / 지출항목, 은행과 다수의 고객
 */

class Man{
	private Woman woman;
	private String name;
	public Man(String name) {
		super();
		this.name = name;
	}
	public void info() {
		System.out.println("남자의 이름은 " + name);
		if (woman != null) {
			System.out.println("남자와 그녀는");
			System.out.println("이름 : " + woman.getName());
			System.out.println("나이 : " + woman.getAge());
			System.out.println("사는 곳 : " + woman.getLoc());
		} else {
			System.out.println("음슴");
		}
	}
	public Woman getWoman() {
		return woman;
	}
	public void setWoman(Woman woman) {
		this.woman = woman;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	
}

class Woman {
	private String name;
	private int age;
	private String loc;
	public Woman() {
		super();
	}
	public Woman (String name, int age, String loc) {
		super();
		this.name = name;
		this.age = age;
		this.loc = loc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
}

public class A01_ClassVsClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Object o = new Woman();	// 할당은 promote형식으로 자동으로 되지만
//		w1.getLoc();			// casting 과정 전에는 사용할 수 없음
		Woman w1 = (Woman)o;	// 해당클래스의 정의된 메서드를 사용하기 위해서는 casting 과정이 필요
		w1.getLoc();
		
		
		Woman w2 = new Woman("이영자", 27, "마포대교는");
		Man m1 = new Man("홍길동");
		m1.setWoman(w2);
		m1.info();
		
		System.out.println();
		
		person03 ps03 = new person03("김현태");
		ps03.inMyPocket();
		ps03.setCellphone(new cellPhone("Galaxy Fold"));
		ps03.inMyPocket();
		

	}

}

/* ex)	Person, HandPhone
	@@은
	@@@ 핸드폰을 가지고 있다
	핸드폰이 없다
 */ 

class person03 {
	private String name;
	private cellPhone cellphone;
	public person03(String name) {
		super();
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public cellPhone getCellphone() {
		return cellphone;
	}
	public void setCellphone(cellPhone cellphone) {
		this.cellphone = cellphone;
	}
	
	public void inMyPocket() {
		System.out.println(name + "이 가지고 있는 핸드폰");
		if ( cellphone != null ) {
			System.out.println(cellphone.getKind() + " 핸드폰을 가지고 있긔");
		} else {
			System.out.println("핸폰 음슴");
		}
	}
}

class cellPhone {
	private String kind;

	public cellPhone(String kind) {
		super();
		this.kind = kind;
	}

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}
	
}