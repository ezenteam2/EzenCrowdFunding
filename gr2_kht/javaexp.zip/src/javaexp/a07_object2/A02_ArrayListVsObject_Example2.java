package javaexp.a07_object2;

import java.util.ArrayList;

/*
년도별 프로야구팀 (rank3) 성적 처리
1 : 다 관계로
2019, 2018 데이터 기준
 */

/*
class TeamRank {
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	private String name;
	private int rank;
	
	public TeamRank() {
		super();
	}
	
	public TeamRank(String name, int rank) {
		super();
		this.name = name;
		this.rank = rank;
	}
	
}

class rgTeamRank {
	private String year;
	private ArrayList<TeamRank> teamRankList;
	public rgTeamRank(String year) {
		super();
		this.year = year;
		teamRankList = new ArrayList<TeamRank>();
	}
	
	public void regiTeamRank(TeamRank ins) {
		teamRankList.add(ins);
	}
	
	public void searchStudent(String name) {
		TeamRank tr = null;
		for (TeamRank trr : teamRankList) {
			if (trr.getName().equals(name)) {
				tr = trr;
			}
		}
		System.out.println(" # 팀이름 : " + name);
		System.out.println(tr.getName() + "\t");
		System.out.println(tr.getRank() + "위");
		System.out.println();
	}
	
	public void showTeamList() {
		System.out.println(" 전체 순위 ");
		for (TeamRank trrr : teamRankList) {
			System.out.println(trrr.getName() + "\t");
			System.out.println(trrr.getRank() + "\t");
			System.out.println();
		}
	}
}


public class A02_ArrayListVsObject_Example2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	rgTeamRank Tr = new rgTeamRank("삼성");
	Tr.regiTeamRank(null);
	

	}

}

*/

class BaseBall{
	private String league;
	private ArrayList<Team> tlist;
	public BaseBall(String league) {
		super();
		this.league = league;
		tlist = new ArrayList<Team>();
	}
	public void regTeam(Team team) {
		System.out.println("# 팀 등록 #");
		tlist.add(team);
	}
	public void showLeague() {
		System.out.println("# "+league+"년 시리즈 성적 #");
		System.out.println("no\t팀\t승\t패\t무\t승률");
		for(int idx=0;idx<tlist.size();idx++) {
			System.out.print(idx+1+"\t");
			// tlist.get(인덱스) : 단위 객체..
			tlist.get(idx).showRecord();
		}
	}
	
}
class Team{
	private String tname;
	private int vic;
	private int def;
	private int equ;
	public Team(String tname, int vic, int def, int equ) {
		super();
		this.tname = tname;
		this.vic = vic;
		this.def = def;
		this.equ = equ;
	}
	public void showRecord() {
		System.out.print(tname+"\t");
		System.out.print(vic+"\t");
		System.out.print(def+"\t");
		System.out.print(equ+"\t");
		double vicRatio = vic/(double)(vic+def);
		// 출력 형식처리.. printf("%자리수.소숫점이하f",매핑될 데이터)
		System.out.printf("%4.3f\n",vicRatio);
	}
	
}

public class A02_ArrayListVsObject_Example2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BaseBall b2019 = new BaseBall("2019");
		b2019.regTeam(new Team("SK",88,55,1));
		b2019.regTeam(new Team("두산",88,55,1));
		b2019.regTeam(new Team("히어로즈",86,57,1));
		b2019.showLeague();
		
		BaseBall b2018 = new BaseBall("2018");
		b2018.regTeam(new Team("두산",93,51,0));
		b2018.regTeam(new Team("SK",78,65,1));
		b2018.regTeam(new Team("한화",77,67,0));
		b2018.showLeague();		

	}

}
