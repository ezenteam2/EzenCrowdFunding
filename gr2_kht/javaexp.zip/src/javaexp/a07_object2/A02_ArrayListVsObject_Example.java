package javaexp.a07_object2;

import java.util.ArrayList;

//index로 2
//ex)	구매한 물건을 list할려고 한다..
//   	Product 클래스 (물건명, 가격, 갯수)로 선언하고,
//    	ArrayList에  물건객체를 3개 이상 담아서,
//    	두번째 물건의 총비용을 출력 처리하세요..

class product {
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	private String name;
	private int price;
	private int no;
	
	public product() {
		super();
	}
	
	public product (String name, int price, int no ) {
		super();
		this.name = name;
		this.price = price;
		this.no = no;
	}
	
	public void show () {
		System.out.print("제품명 : " + name + "\t\t");
		System.out.print("가격 : " + price + "\t\t");
		System.out.print("갯수 : " + no + "\t\t");
		
	}
	
	
}

public class A02_ArrayListVsObject_Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<product> shoppingList01 = new ArrayList<product>();
		
		shoppingList01.add(new product("딸기", 5000, 3));
		shoppingList01.add(new product("바나나", 2000, 6));
		shoppingList01.add(new product("아이스크림", 1000, 3));
		shoppingList01.add(new product("칸쵸", 1500, 1));
		shoppingList01.add(new product("신라면", 4500, 2));
		
		int productPrice;
		int tot = 0;
		
		for (int idx = 0; idx < shoppingList01.size(); idx++) {
			product pro = shoppingList01.get(idx);
			//pro.getName();
			//pro.getPrice();
			//pro.getNo();
			productPrice = pro.getPrice() * pro.getNo();
			tot += productPrice;
			pro.show();
			System.out.print("물건 가격 : " + productPrice);
			System.out.println();			
			
		}
		
		System.out.println();
		System.out.println("총 가격 : " + tot);

	}

}
