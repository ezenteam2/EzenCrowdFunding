package javaexp.a07_object2;

import java.util.ArrayList;

/*
 	* Array는 한 번 만들어지면, 크기를 변경할 수 음슴
 	* 동적 배열은 배열이 작아지기도, 커지기도 하여 효과적으로 활용 가능
 	* ArrayList - JAVA에서 동적배열을 지원하는 객체

# ArrayList
	1. 선언	- ArrayList 참조변수 = new ArrayList();	// java.util.하위package - import 필요
	2. 들어갈 데이터 type의 설정
		1) 객체형식으로 generic 활용 가능
			- 	선언하지 않아도 모든 객체의 최상위 객체인 object가 자동으로 선언되어 할당은 할 수 있으나,
				casting과정 필요
			ex)	ArrayList<String> list = new ArrayList<String>();
				ArrayList<Integer> list = new ArrayList<Integer>();
				ArrayList<Product> list = new ArrayList<Product>();
		2) ArrayList를 문자열로 할당하도록 선언 후
			- 데이터 추가 		: 참조변수.add("추가할 문자열");
			- 데이터 가져오기	: 참조변수.get("인덱스 번호");
			- 데이터 수정		: 참조변수.set(인덱스번호, "변경될 데이터")
			- 데이터 삭제		: 참조변수.remove(인덱스번호)

 */

public class A01_DynamicArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		ArrayList<String> fruitList = new ArrayList<String>();	// 문자열이 배열로 들어갈 수 있는 동적 배열 선언
																// 객체가 heap 영역에 생성 됨
		fruitList.add("바나나");
		fruitList.add("딸기");
		fruitList.add("사과");
		System.out.println(fruitList.get(0));
		System.out.println(fruitList.get(1));
		System.out.println(fruitList.get(2));
		System.out.println("동적 배열의 크기(배열이름.size) : " + fruitList.size());
		System.out.println();
		
		for (int idx = 0; idx < fruitList.size(); idx ++) {
			System.out.println(fruitList.get(idx));
		System.out.println();
			
		//ex) 	무지개 색상을 할당
		//		반복문을 통하여 출력
		//		7개 색상 중 임의의 색상을 흰색으로 변경
		//		첫번째와 마지막 색상을 삭제한 후, 남은 색상 list를 반복문으로 출력
		
		ArrayList<String> Rainbow = new ArrayList<String>();
		Rainbow.add("빨강");
		Rainbow.add("주황");
		Rainbow.add("노랑");
		Rainbow.add("초록");
		Rainbow.add("파랑");
		Rainbow.add("남색");
		Rainbow.add("보라");
		
		for (idx = 0; idx < Rainbow.size(); idx++) {
			System.out.print(Rainbow.get(idx) + "\t");
		}
		
		System.out.println();
		
		Rainbow.set((int)(Math.random() * Rainbow.size()), "흰색");
		
		for (idx = 0; idx < Rainbow.size(); idx++) {
			System.out.print(Rainbow.get(idx) + "\t");
		}
		
		System.out.println();
		
		Rainbow.remove(0);
		Rainbow.remove(Rainbow.size() - 1);
		
		for (idx = 0; idx < Rainbow.size(); idx++) {
			System.out.print(Rainbow.get(idx) + "\t");
		}
		
		
		}
		

	}

}
