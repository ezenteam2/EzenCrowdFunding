package javaexp.a07_object2;

import java.util.ArrayList;

class Student {

	private String name;
	private int kor;
	private int eng;
	private int math;
	public Student() {
		super();
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	
	public Student (String name, int kor, int eng, int math) {
		super();
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.math = math;
	}
	
}

public class A02_ArrayListVsObject {

/*
	ArrayList<데이터유형>
	ArrayList<class명> : 여러개의 속성값을 가진 객체 단위의 동적 배열
 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	ArrayList<Student> class01 = new ArrayList<Student>();
	//	단위 객체들 추가 처리 ( .add(new 클래스명());
	//	[(속성1, 속성2), (속성1, 속성2), (속성1, 속성2), (속성1, 속성2)]
	
	class01.add(new Student("홍길동", 90, 90, 95));
	class01.add(new Student("신길동", 80, 80, 70));
	class01.add(new Student("김길동", 60, 85, 70));
	class01.add(new Student("마길동", 30, 60, 70));
	
	// ArrayList안에 포함된 객체의 속성 접근
	//		1) ArrayList의 참조 변수 호출
	//		2) 해당 참조변수의 순반을 index로 호출 : 참조변수.get(index)
	//		3) 속성 접근 : .getXXX() 개체에 포함된 속성 접근
	
	// ex) 1반 첫번째 학생 이름과 영어 점수 출력
	
	int sum;
		
	for (int idx = 0; idx < class01.size(); idx++) {
		Student stu = class01.get(idx);
		stu.getName();
		stu.getKor();
		stu.getEng();
		stu.getMath();
		sum = 	class01.get(idx).getKor() +
				class01.get(idx).getEng() +
				class01.get(idx).getMath();
		System.out.print("이름 : " + stu.getName() + "\t");
		System.out.print("국어 : " + stu.getKor() + "\t\t");
		System.out.print("영어 : " + stu.getEng() + "\t\t");
		System.out.print("수학 : " + stu.getMath() + "\t\t");
		System.out.print("총점 : " + sum + "\t");
		System.out.print("평균 : " + (sum / 3) + "\t");
		System.out.println();
	}

	
	System.out.println();
	System.out.println();
	
	SchoolClass sc = new SchoolClass("3 - 2");
	sc.regStudent(new Student("김현태", 100, 100, 100));
	sc.regStudent(new Student("마현태", 10, 20, 100));
	sc.regStudent(new Student("이현태", 20, 80, 85));
	sc.regStudent(new Student("최현태", 80, 95, 95));
	sc.showList();
	System.out.println();
	System.out.println();
	sc.searchStudent("김현태");
	
	}

}

//1 : (여러 클래스) 구성

class SchoolClass {
	private String clsName;
	private ArrayList<Student> slist;
	public SchoolClass(String clsName) {
		super();
		this.clsName = clsName;
		slist = new ArrayList<Student>();
	}
	
	// 학생 정보 등록
	public void regStudent(Student ins) {
//		System.out.println("# 학생 정보 등록 #");
		slist.add(ins);
	}
	
	// 학생 성적 조회
	public void searchStudent(String name) {
		Student sc = null; //조회 된 학생
		for(Student sch : slist) {
			if(sch.getName().equals(name)) {		// 이름이 일치하는 경우
				sc = sch;								// 조회된 학생 객체를 할당
			}
		}
		System.out.print("# 이름 : " + name + " 학생 정보");
		System.out.println();
		System.out.print(sc.getName() + "\t");
		System.out.print(sc.getKor() + "\t");
		System.out.print(sc.getEng() + "\t");
		System.out.print(sc.getMath() + "\t");
	}
	
	// 전체 학생 정보 출력
	public void showList() {
		System.out.println(" # " + clsName + "반 학생 성적 #");
		for (Student std : slist) {			
			System.out.print(std.getName() + "\t");
			System.out.print(std.getKor() + "\t");
			System.out.print(std.getEng() + "\t");
			System.out.print(std.getMath() + "\t");
			System.out.println();
		}
	}
}


