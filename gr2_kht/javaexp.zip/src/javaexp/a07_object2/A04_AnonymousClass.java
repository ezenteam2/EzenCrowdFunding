package javaexp.a07_object2;

abstract class GrandPerson{
	abstract void show();
}

class Person2{
	public void call() {
		System.out.println("안녕하세요!!(일반클래스)");
	}
	void show() {
		System.out.println("출력내용");
	}
}

public class A04_AnonymousClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person2 p1 = new Person2();
		p1.call();
		
		Person2 p2 = new Person2() {
			public void call() {
				System.out.println("익명클래스");
			}
			public void gogo() {
				System.out.println("고고 고고");
			}
			@Override
			void show() {
				// TODO Auto-generated method stub
				System.out.println("새로 정의하여 처리한 내용");
			}
			
		};
		
		p2.call();
		
		
	}

}
