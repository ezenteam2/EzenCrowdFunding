package javaexp.a09_api;


public class A02_equals_hashcode {

public void Woman(String name) {
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*
# equals
		1. 문자열의 내용을 비교할 때 동일 문자열 확인
		2. == : 주소값 확인
 */
		
		String name01 = new String("하이맨");
		String name02 = new String("하이맨");
		System.out.println("주소값 비교 : " + (name01==name02));
		System.out.println("내용 비교 : " + name01.equals(name02));
		
		
/*
# 객체 해시코드(hashCode())
	1. 해시코드
		1) 객체를 식별할 하나의 정수값
		2) 객체의 메모리 주소를 이용하여 해시코드로 만든 값을 리턴
			- 개별 객체의 해시코드는 모두 상이
	2. 논리적 동등 비교시 hashCode() 오버라이딩의 필요성
		1)	컬렉션 프레임워크의 HashSet, hashMap, Hashtable과 같은 클래스는 두 객체가 동등한 객체인지 판단할 때,
			다음과 같은 과정을 거침
			hashCode() 리턴값	--같음--> equals() 리턴값	--같음--> 동등 객체
							|							|
							--다름		다른 객체		<--다름
 */
		

		Woman w1 = new Woman("이진주");
		Woman w2 = new Woman("이진주");
		
		
	}

}
