package javaexp.a09_api;

public class A03_Clone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*
# 객체 복제 (Clone)
	1. 원본 객체의 필드 값과 동일한 값을 가지는 새로운 객체를 생성
	2. 복제 종류
		1) 얕은 복제 (thin clone) : 필드 값만 복제 (참조 타입 필드는 주소를 공유)
			- heap 번지를 공유하기 때문에, 복제 전 데이터의 필드값을 변경하면 복제한 객체도 영향을 미침
		2) 깊은 복제 (deep clone) : 참조하고 있는 객체를 복제
			- 새로운 heap 영역에 객체를 복제
	3. Object의 clone() 메소드
		1) 동일한 필드 값을 가진 얕은 복제된 객체를 리턴
		2) java.lang.Cloneable 인터페이스를 구현한 객체만 복제 가능
	4. 깊은 복제 - clone() 메소드를 재정의하고 참조 객체조 복제
 */
		

	Friend f1 = new Friend("홍길동");
	System.out.println("f1 객체 : " + f1);
	System.out.println("f1의 이름 : " + f1.getName());
	//객체 생성	

	Friend f2 = f1;	//얕은 복사 (주소값 할당)
	System.out.println("f2 주소 : " + f1);
	System.out.println("f2의 이름 : " + f1.getName());
	System.out.println("얕은 복사 후, f1과 f2의 속성변경");
	f2.setName("신길동");
	System.out.println("f1의 이름 : " + f1.getName());
	System.out.println("f2의 이름 : " + f2.getName());

	
	// clone()을 통한 복사 - 깊은 복사
	Friend f3 = f1.getFriend();
	System.out.println("#f3의 이름 변경");
	f3.setName("마길동");
	System.out.println("f1의 이름 : " + f1.getName());
	System.out.println("f3의 이름 : " + f3.getName());
	}

}

class Friend implements Cloneable{

	private String name;
	
	public Friend() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Friend(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Friend getFriend() {
		Friend cloned = null;
		// 현재 clone()을 이용하여 복제
		try {
			cloned = (Friend)clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return cloned;
		
	}
	
	
}