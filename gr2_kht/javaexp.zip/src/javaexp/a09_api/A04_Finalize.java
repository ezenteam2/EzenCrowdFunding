package javaexp.a09_api;

class Counter{
	private int cnt;

	public Counter(int cnt) {
		super();
		this.cnt = cnt;
		// TODO Auto-generated constructor stub
	}	
	// 소멸 시 호출할 메서드 재정의
	
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
		System.out.println((cnt+"소멸자 호출!!!!!"));
	}	

	
}

public class A04_Finalize {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*
# 객체 소멸자
	1. GC(Garbage Colletion) - 객를 소멸하기 직전 객체 소멸자 (finalize())를 실행
	2. Object의 finalize()는 기본적으로 실행 내용 없음
	3. 객체가 소멸되기 전에 실행할 코드가 있다면, Object finalize()를 재정의
	4. 가능한한 소멸자는 사용하지 말것
		1) GC는 메모리의 모든 쓰래기 객체를 소멸하지 않음
		2) GC는 구동 시점이 일정하지 않음
*/

		Counter cntObj = null;
		for(int cnt=1;cnt<=100;cnt++) {
			cntObj = new Counter(cnt);	// 객체 생성
			cntObj = null;				// 객체를 메모리에서 제거
			
			System.gc(); 				// 메모리 자동 정리 호출
		}
		
	}

}
