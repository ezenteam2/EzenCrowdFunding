package javaexp.a09_api;

import java.io.IOException;

import javaexp.a04_object.Person;

public class A01_Lang_package {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*
1. java.lang 패키지는 java default API 패키지
2. import 하지 않아도 사용 가능

# JAVA의 최상위 class object
	1. 최상위 클래스이므로, 선언된 메서드는 모든 클래스에서 사용 가능
	2. 최상위 클래스이므로, 모든 사용자 클래스도 다형성에 의해 할당 가능
 */
		
		Object o01 = new Object();
		Object o02 = new Person();

/*
	3. 주요 매서드
		- toString() : 참조 변수에 의해 나타날 내용을 정의
						ex) 패키지명.객체명@16진수 heap영역 주소값
 */

		System.out.println("참조변수 o01 : " + o01);
		System.out.println("참조변수 o01.toString() : " + o01.toString());
		
/*
		System.in : 자바의 표준 입력을 처리하는 객체
		read() : 입력된 내용을 char형식으로 가져옴
		System.out : 자바의 표준 출력을 처리하는 객체
		prtin(), println(), printf() 등을 이용하여 출력
 */

		try {
			System.out.println("표준 입력 : " + (char)System.in.read());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
