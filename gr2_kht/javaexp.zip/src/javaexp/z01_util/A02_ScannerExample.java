package javaexp.z01_util;

import java.util.Scanner;

public class A02_ScannerExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		//ex1) 이름, 나이, 사는 곳을 입력 받아 출력

		System.out.print("이름 : ");
		String name = sc.nextLine();
		System.out.print("나이 : ");
		String age = sc.nextLine();
		System.out.print("사는 곳 : ");
		String location = sc.nextLine();
		System.out.println();
		System.out.println("이름 : " + name + "\t 나이 : " + age + "\t 사는 곳 : " + location);
		System.out.println();

		//ex2) 국어, 영어, 수학 점수를 입력 받아 출력하고, 총점과 평균도 출력
		
		System.out.print("국어 점수 : ");
		int korean = sc.nextInt();
		System.out.print("영어 점수 : ");
		int english = sc.nextInt();
		System.out.print("수학 점수 : ");
		int math = sc.nextInt();
		int total = korean + english + math;
		double avg = total / 3;			//소수점 이하의 숫자를 살려야 하는 경우
		System.out.println();
		System.out.println("총점 : " + total + "\t 평균 : " + avg);
		// 소수점 이하 자리 수 설정 : %자리수.자리수f : 실수 표현
		// %자리수d : 정수표현
		System.out.printf("평균 : %2.2f\n", avg);
		System.out.println();
		
	}

}
