package javaexp.z01_util;

public class A03_Random {

/*
# Math.random()
1. 0.0 <= R < 1.0 에 만족하는 임의의 실수를 불러 옴
2. 특정 범위 내의 실수를 불러 오기 위해서
 	1) 0.0 * 6 <= Math.random() * 6 < 1.0 * 6
 	2) 0.0 <= Math.random() * 6 < 6
 	3) 0.0 <= (int)(Math.random() * 6) < 6		=> 도출 가능한 결과값 : 0, 1, 2, 3, 4, 5
 	4) 0.0 <= (int)(Math.random() * 6) + 1 < 6	=> 도출 가능한 결과값 : 1, 2, 3, 4, 5, 6 >>>>> 주사위 결과값을 만들 수 있음
3. 특정한 정수를 임의로 출력하는 처리 공식
	1) (int)(Math.random() * 경우의 수) + 시작번호
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//주사위
		System.out.println((int)(Math.random() * 6) + 1);
		System.out.println();
		
		//구구단
		// 2 <= grade <= 9
		// 1 <= cnt <= 9
		int grade = (int)(Math.random() * 8) + 2;
		int cnt = (int)(Math.random() * 9) + 1;
		System.out.println(grade + " * " + cnt + " = " + (grade * cnt));
		System.out.println();

		// 가위 바위 보 임의로 나오게 하기
		String game[] = {"가위", "바위", "보"};
		System.out.println(game[0] + " : " + game[1] + " : " + game[2]);
		// 0, 1, 2 중 임의의 숫자가 나오게 하여 game배열의 index로 할당
		int ranIdx = (int)(Math.random() * 3);
		System.out.println("가위! 바위! 보 : " + game[ranIdx]);
		System.out.println();
		
		// ex1) 주사위 2개를 던져 합산된 번호를 출력
		int dice01 = (int)(Math.random() * 6) + 1;
		int dice02 = (int)(Math.random() * 6) + 1;
		int diceTotal = dice01 + dice02;
		System.out.println("1번 주사위 : " + dice01);
		System.out.println("2번 주사위 : " + dice02);
		System.out.println("결과는 ? " + diceTotal);
		System.out.println();
		
			
		// ex2) 임의의 카드 한장(◆, ♠, ♥, ♣)*(A, 1, 2, 3, 4, 5, 6, 7, 8, 9, J, Q, K)을 뽑아 보세여
		// 배열이름.length = 배열의 길이
		String mark[] = {"◆", "♠", "♥", "♣"};
		int ranMark = (int)(Math.random() * mark.length);
		String num[] = {"A", "1", "2", "3", "4", "5", "6", "7", "8", "9", "J", "Q", "K"};
		int ranNum = (int)(Math.random() * num.length);
		System.out.println("뽑은 카드는 ? " + mark[ranMark] + num[ranNum]);
		System.out.println();
	} 

}
