package javaexp.z01_util;

import java.util.Scanner;

public class A02_Scanner {

/*
- 입력 처리 : System.in
- 출력 처리 : System.out
- Scanner 객체와 System.in을 통해서 Console에서 입/출력을 처리할 수 있게 해준다.

 		
 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//1. 객체 생성과 입력 매개변수 설정	
		//	1) 내장된 객체를 import 처리
		Scanner sc = new Scanner(System.in);
		//2. 문자열을 입력 받아서 처리
		/*
		// 단어 입력 : .next()
		System.out.print("이름을 입력하세용 : ");
		String name = sc.next();				//한 단어로 입력
		System.out.println("이름 : " + name);
		System.out.print("사는 곳을 입력하세용 : ");
		String loc = sc.next();					//한 단어로 입력
		System.out.println("사는 곳 : " + loc);	//print"ln" => ln은 줄바꿈을 의미함
 		*/
		
		/*
		// 라인별 입력 (enter까지) : .nextLine()
		System.out.println("인사말을 입력하세용 : ");
		String lineIn = sc.nextLine();			//문장 입력 가능
		System.out.println("인사말 : " + lineIn);
		System.out.println("목적지를 입력하세용 : ");
		String lineIn2 = sc.nextLine();			//문장 입력 가능
		System.out.println("목적지 : " + lineIn2);
		*/
		
		/*
		// 정수형 숫자 입력 : .nextInt()
		System.out.print("첫 번째 숫자 입력 : ");
		int num01 = sc.nextInt();
		System.out.print("두 번째 숫자 입력 : ");
		int num02 = sc.nextInt();
		System.out.println("더하면 얼마?");
		System.out.println("옛다 " + num01 + " + " + num02 + " = " + (num01 + num02));
		*/
		
		/*
		// 실수형 숫자 입력 : .nextDouble()
		
		System.out.print("1번 지원자 키 : ");
		double height01 = sc.nextDouble();
		System.out.print("2번 지원자 키 : ");
		double height02 = sc.nextDouble();
		double avg = (height01 + height02) / 2;
		System.out.println("평균 : " + avg + "cm");
		if (avg >= 170) {
			System.out.println("오 평균 이상이시네여");
		} else {
			System.out.println("혹시 드워프 출신?");
		}
		*/
		
		//ex1) 이름, 나이, 사는 곳을 입력 받아 출력
		//ex2) 국어, 영어, 수학 점수를 입력 받아 출력하고, 총점과 평균도 출력
	}

}
