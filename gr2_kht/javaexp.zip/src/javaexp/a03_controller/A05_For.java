package javaexp.a03_controller;

import java.util.Scanner;

public class A05_For {

	
/*
# for
	1. 변수를 이용하여 증가나 감소 처리를 통해 명령문을 반복할 때
	2. 형식
		for( (초기값); (반복 조건); (증감연산자) ) {
		(변수와 함께 반복처리할 명령)
		}
	3. ex)
		for(int cnt = 1; cnt <= 10; cnt++) {
			System.out.println(cnt +"번째 안녕하세요~~");
		}
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*
		//카운트 다운 예제
		Scanner sc01 = new Scanner(System.in);
		System.out.print("카운트 얼마? ");
		int cnt = sc01.nextInt();
		for (int cnt01 = cnt; cnt01 >=0 ; cnt01--) {
			System.out.println("카운트다운 " + cnt01);
		}
		System.out.println("끗");
		System.out.println();
		
		//ex1) 숫자를 입력 받아 구구단으로 출력
		Scanner sc02 = new Scanner(System.in);
		System.out.print("몇 단 공부하싈? ");
		int num01 = sc02.nextInt();
		System.out.println(num01 +"단 시작!!!!!");
		for (int i = 1; i <= 9; i++) {
			System.out.println(num01 + " * " + i + " = " + (num01 * i));			
		}
		System.out.println();
		
		//1 ~ 100까지 5씩 증가처리
		for (int abc01 = 0; abc01 <= 100; abc01+=5) {
		System.out.println(abc01);
		}
		
		//100 ~ 1까지 감소처리
		for (int abc02 = 100; abc02 >= 1; abc02--) {
			System.out.print(abc02 + "\t");
			if(abc02 % 5 == 1) {
				System.out.println();
			}
		}
		System.out.println();
		
		//ex1) 5 ~ 20까지 홀수
		for (int abc03 = 5; abc03 <= 20; abc03+=2) {
			System.out.println(abc03);
		}
		System.out.println();
		
		//ex2) 30 ~ 15까지 3씩 감소
		for (int abc04 = 30; abc04 >= 15; abc04-=3) {
			System.out.println(abc04);
		}
		
		//for(초기값; 한계치; 증감)
		//배열의 데이터를 효과적으로 처리할 수 있다
		String fruits[] = {"사과", "바나나", "딸기"};
		System.out.println("배열의 값 : " + fruits[0]);
		System.out.println("배열의 길이 : " + fruits.length);
		System.out.println();

		//for문과 배열처리
		//for(초기 index를 설정; 배열의 길이까지의 범위; index증가)
		System.out.println("배열의 index");
		//idx < fruits.length => 배열의 index가 배열의 길이보다 1적으므로
		for (int idx = 0; idx < fruits.length; idx++) {
			System.out.print(idx + "\t");
			System.out.println(fruits[idx]);
		}
		
		for (int idx = 0; idx <args.length; idx++) {
			System.out.print(idx + "\t");
			System.out.println(args[idx]);
		}

*/
		
		//ex2) 	배열을 사용하여 월별 입금액 120000 1000000 50000원을 선언하여 출력
		//		총합을 출력

	int[] deposit  = {120000, 1000000, 50000, 12000, 3500000, 57800, 600000, 124000};
	int total = 0;
	for (int month = 0; month < deposit.length; month++) {
		System.out.println((month + 1) + "월 입금액 : " + deposit[month]);
		total += deposit[month];
	}
	System.out.println();
	System.out.println("총 합은 ? " + total);
	}

}
