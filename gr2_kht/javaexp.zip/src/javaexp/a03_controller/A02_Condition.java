package javaexp.a03_controller;

public class A02_Condition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*
# 조건문
	1. 조건식 결과에 따라 중괄호({}) 블록을 실행여부를 다르게 설정할 때
	2. 형식
	 	if( 조건식1 ) {
	 		조건식1이 true일 때, 처리할 내용
	 	}									=> 조건식1이 false이면 해당 조건문은 종료
		
		if( 조건식2 ) 조건식 2가 true일 때, 처리할 내용
		
		if( 조건식3 );
			조건식3이 true일 때, 처리할 내용
		
		if( 조건식4 ) {
			조건식4가 true일 때, 처리할 내용
		} else {
			조건식4가 false일 때, 처리할 내용
		}
 */
		
		int num01 = 25;
		int num02 = 30;
		System.out.println("# 덧셈 문제 #");
		System.out.println(num01 + " + " + num02);
		int answer = 55;
		System.out.println(("입력 값 : " + answer));
		if ( (num01 + num02) == answer) {
			System.out.println("오, 왠일?");
		} else {
			System.out.println("내 그럴줄 알았지");
		}
		
		//ex1) 물건명 가격 갯수를 args로 입력 받아, 총 비용이 500000원 이상이면 VIP 고객입니다를 출력
		
		int price = Integer.parseInt(args[1]);
		int number = Integer.parseInt(args[2]);
		if ( price * number >= 500000) {
			System.out.println(args[0] + "을/를 " + price * number + "원치 구입하셨네요");
			System.out.println(args[3] + " 호갱님 알아서 모시겠습니다");
		} else {
			System.out.println(args[0] + "을 /를" + price * number + "원치 구입하셨네요");
			System.out.println(args[3] + "님 겨우 이거 사셨어요?");
		}
	}

}
