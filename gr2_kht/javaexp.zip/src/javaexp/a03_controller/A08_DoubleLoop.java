package javaexp.a03_controller;

import java.util.Scanner;

public class A08_DoubleLoop {

/*
# 중첩 반복문과 중첩 조건문
1. 반복문 안에 반복문을 수행
		ex) 구구단 전체 출력 (2 ~ 9, 단수 처리 & 1 ~ 9, 곱셈식 처리)
	1) 형식
		if ( ) {
			if ( ) {
			} else {
			}
		} else {
		}
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*		
		for (int grade = 2; grade <= 9; grade++) {
		
			System.out.print("### " + grade + "단 ### \t");
		
		}
		
		System.out.println();
		
		for (int grade = 1; grade <= 9; grade++) {
			
			for (int no01 = 2; no01 <= 9; no01++) {
			System.out.print(no01 + " * " + grade + " = " + (no01 * grade) + "\t");
			
			}
			
		System.out.println();
		
		}
		
		System.out.println();
		
		for (int grade = 2; grade <= 9; grade++) {
			
			System.out.print("### " + grade + "단 ### \t");
			
			for (int no01 = 1; no01 <= 9; no01++) {
				
				System.out.print(grade + " * " + no01 + " = " + (grade * no01) + "\t");
			}
		
		System.out.println();
		
		}

		System.out.println();
		
		//ex2) 나이에 따른 성인 여부 check, 남녀를 출력
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("나이를 입력하세요 : ");
		int age = sc.nextInt();
		System.out.print("주민등록번호 뒷번호 첫자리 (1 / 2) : ");
		int gender = sc.nextInt();
		
		if ( age >= 20 ) {
			
			if ( gender % 2 == 1 ) {
				System.out.println("성인 남성입니다");
			} else {
				System.out.println("성인 여성입니다");
		
			}
		} else {
			
			if ( gender % 2 == 1 ) {			
				System.out.println("미성년자 남성입니다");				
			} else {				
				System.out.println("미성년자 여성입니다");				
			}

		}
*/
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("나이를 입력하세요 : ");
		int age01 = sc.nextInt();
		System.out.print("오늘은 무슨요일? (월 / 화 / 수 / 목 / 금 / 토 / 일) : ");
		char day = sc.next().charAt(0);
				
		if (age01 < 4 || age01 >= 65) {

			System.out.println("무료로 입장!!!!!");

		} else {

			if (day == '토') {

				System.out.println("반값 입장!!!!!");

			} else if (day == '일') {

				System.out.println("내 그대를 위해 80퍼 할인 해 드림");

			} else {

				System.out.println("제값 다 내고 입장하세여 호갱님");

			}
		}
		
	}

}
