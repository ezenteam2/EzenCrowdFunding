package javaexp.a03_controller;

public class A03_if_else {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
# if + else if
1. 여러 가지 분기 조건을 처리할 때 활용
2. 형식

if( 조건식1 ) {
	조건식1이 true일 때, 처리할 내용
} else if( 조건식2 ) {
	조건식2가 true일 때, 처리할 내용
} else if( 조건식3 ) {
	조건식3이 true일 때, 처리할 내용
} else if( 조건식4 ) {
	조건식4가 true일 때, 처리할 내용
} else {
	조건식 1, 2, 3, 4가 모두 false일 때 처리할 내용
}												==>>> else if의 선행 되는 조건문이 true일 경우 그 이 후의 내용들은 처리되지 않음!
 */
		
		int score = 80;
		String result = "";
		if (score >= 90) {
			result = "A 그만 하산하거라";
		} else if (score >= 80) {				// == } else if (!(score >= 90) && score >= 80) {
			result = "B 3시간만 더 하지";
		} else if (score >= 70) {
			result = "C 또 들어도 B이상 불가";
		} else if (score >= 60) {
			result = "D 너의 수강 취소가 가취있기를";
		} else {
			result = "F 가망이 없다";
		}
		System.out.println("너는 " + result);
	
	
	//ex1)age를 기준으로
	//		0 미만 : 범위에서 벗어남
	//		1 ~ 4 또는 65 이상 : 무료 입장
	//		5 ~ 13 : 어린이 할인 (50%)
	//		14 ~ 19 : 청소년 요금제 (30%)
	//		20 ~ 64 : 일반 요금제
	

		int age = 12;
		int price = 200000; 
		
		if (age < 0) {
			System.out.println("아직 존재하지 않는 녀석이구나");
		} else if (age <= 4 || age >= 65) {
			System.out.println("어서어서 입장~~~~");
		} else if (age >= 5 && age <= 13) {
			System.out.println("너는 쪼렙");
			System.out.println(price * 0.5 + "만 내고 드루와");
		} else if (age >=14 && age <= 19) {
			System.out.println("미자 주제에 어딜");
			System.out.println(price * 0.7 + "을 내고 오너라");
		} else {
			System.out.println("어서오세요 호갱님");
		}
	}
}
