package javaexp.a03_controller;

import java.util.Scanner;

public class A06_While {

/*
# while
	1. boolean 조건이 true인 경우 계속해서 반복 
	2. 기본 형식
		while(boolean 조건) {
			boolean 조건이 true일 때 실행할 명령문
		}
# do-while
	1. 조건과 상관 없이 do{}블럭을 일단 1번 수행하고, 반복 조건이 true일 때, 반복처리하는 구문
	2. 기본 형식
		do {
			일단 1번 수행할 명령문
		} while ( 반복 조건 );
	3. 손님이 들어왔을 때, 주문은 하지 않더라도 인사는 한다!!!! 그 후에 반복적으로 메뉴를 주문 받는다.
 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*		
		int num01 = 1;
		while (num01 <= 50) {
			System.out.println(num01++ + "번 째 반복중");
		}
		
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.println("R u ready to order?");
			String order = sc.nextLine();
			System.out.println(order + "을/를 주문하셨습니다");
			System.out.println("딴거 더 드실래여? (Y / N)");
			String isYN = sc.nextLine();
			if (isYN.contentEquals("N")) {
				break;
			}
	}
		System.out.println("주문이 완료 되어씀미다");
*/

/*
		//ex1) while문을 이용하여, 2의 배수를 20까지 출력하세요.
		int abc01 = 2;
		while (abc01 <=20 ) {
			System.out.println("20 이하 2의 배수 출력 : " + abc01);
			abc01 += 2;
		}
		System.out.println();
		
		//ex2) while문을 이용하여 구구단 9단을 반대로 출력
		int abc02 = 9;
		int abc03 = 9;
		while (abc03 >=1) {
			System.out.println(abc02 + " * " + abc03 + " = " + (abc02 * abc03));
			abc03--;
		}
		System.out.println();
		
		int abc04 = 1;
		do {
			System.out.println("Blazing Friday [" + (abc04++) + "]");
		} while (abc04 <=10);
		System.out.println();

		
		int abc05 = 10000;
		do {
			System.out.println("Blazing Friday [" + (abc05++) + "]");
		} while (abc05 <=10);
		System.out.println();
		
		Scanner sc = new Scanner(System.in);
		String isContinue = null;
		do {
			System.out.println("어서 오세요!!");
			System.out.println("방문을 환영합니다.");
			System.out.println("방문을 계속하시겠습니까? ( Y / N )");
			isContinue = sc.nextLine();
		} while (isContinue.equals("Y"));
		System.out.println("잘가세여");
*/		
		//ex) 회원정보를 등록하시겠습니까?
		// 값이 없으면 벗어나고, 입력값이 있을 시 반복해서 등록된 정보를 출력
		
		
		//infor.length() : 문자열의 크기 - 입력하지 않는 경우 0
		//그 외의 문자 크기 입력하는 경우 infor.length() == 0로 조건 처리
		//System.out.println("등록내용 :" + infor == null);
		//System.out.println("등록내용 :" + infor.length());
		}

	
	}


