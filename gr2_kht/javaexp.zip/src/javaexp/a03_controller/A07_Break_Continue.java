package javaexp.a03_controller;

public class A07_Break_Continue {

/*
# Break와 Continue
1. 반복문이나 조건문에서 주로 process의 중단에 관련된 명령어이다.
2. 기본형식
	1) break
		반복문 ( ) {
			if ( 조건 )
				break;
		}
					=>	반복문 안에서 활용되면, 특정 조건이 만족했을 때, 반복하던 process를 중단
	2) continue
		반복문 ( ) {
		 	처리0;
		 	if ( 조건 )
		 		continue;
		 	처리1;
		 	처리2;
		 }
		 			=>	특정한 범위에서 반복되는 경우, 범위 안에서 반복단위 중 조건을 선언하여,
		 				continue 이후는 처리가 되지 않고 해당 반복 단위의 실행만 중단한 후,
		 				다시 조건문을 반복하도록 함 

		
 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int breakCnt = 7;
		int cnt = 1;
		while ( true ) {
			System.out.println((cnt++) + "번 째 만남!");

			if (cnt == breakCnt) {					// 중단할 조건 선언!
				break;
			}

		}
		
		//ex1) for를 사용하여 기본 반복은 5~20까지 반복, 15에서 중단하도록
		
		System.out.println();
		
		for (int start = 5; start <= 20; start++) {
			System.out.println(start + "을/를 출력했습니다");
			if (start == 15) {
				System.out.println("15가 되었습니다. 프로그램을 종료합니다");
				break;
			}
		}
		System.out.println();
		
		for ( int no01 = 1; no01 <=10; no01++ ) {
			if ( no01 % 2 == 1 ) {
				continue;
			}
			System.out.println("김밥 " + no01 + "줄은 " + (no01 * 1800) + "입니다.");
			}
		
		//ex2) 구구단 5단 출력, * 5는 출력하지 마세용
		
		
		for (int no02 = 1; no02 <= 9; no02++ ) {
			if ( no02 % 5 == 0 ) {
				continue;
			}
			System.out.println("5 * " + no02 + " = " + (5 * no02));
		}
	
	
	}

}
