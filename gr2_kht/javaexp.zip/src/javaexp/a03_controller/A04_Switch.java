package javaexp.a03_controller;

import java.util.Scanner;

public class A04_Switch {

/*
# switch
1. 변수나 연산식의 값에 따라 실행문을 선택하여 사용
2. 형식
	switch(변수) {
		case 변수의 조건1 :		=> : 주의!!! (; 아님)
			처리 내용;
			break;
		case 변수의 조건2 :
			처리 내용;
			break;
		.... case ~ break; 반복 ...
		default :
			어떤 case의 조건도 만족하지 못할 때 실행되는 기본 내용;
	}
 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc01 = new Scanner(System.in);
		System.out.print("몇번 버튼 누르싈 ? ");
		int btnNum = sc01.nextInt();
		System.out.println("선택한 버튼 번호 : " + btnNum);
		switch (btnNum) {
		case 1 :
			System.out.println("1번 구역 불켜짐");
			break;
		case 2 :
			System.out.println("2번 구역 불켜짐");
			break;
		case 3 :
			System.out.println("3번 구역 불켜짐");
			break;
		case 4 :
			System.out.println("4번 구역 불켜짐");
			break;
		case 5 :
			System.out.println("5번 구역 불켜짐");
			break;
		default : 
			System.out.println("뭐하싐?");
			
		}
		
		System.out.println();
		
		//월별 마지막 날짜 처리
		Scanner sc = new Scanner(System.in);
		System.out.print("몇월을 알고 싶으세여 ? ");
		int month = sc.nextInt();
		switch ( month ) {
		//break가 나타날 때까지 계속 수행 됨
		case 1 :
		case 3 :
		case 5 :
		case 7 :
		case 8 :
		case 10 :
		case 12 :
			System.out.println(month + "월 마지막날 : 31일");
			break;
		case 2 :
			System.out.println(month + "월 마지막날 : 28일");
			break;
		case 4 :
		case 6 :
		case 9 :
		case 11 :
			System.out.println(month + "월 마지막날 : 30일");
			break;
		default :
			System.out.println("똑바로 입력하셈");
		}
	}

}
