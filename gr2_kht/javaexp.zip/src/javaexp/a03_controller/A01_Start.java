package javaexp.a03_controller;

public class A01_Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*
# 코드 실행과 흐름 제어
1. main() 안에서 코드는 기본적으로 중괄호 위에서 아래로 실행됨
2. 제어문 - 코드 실행 흐름을 개발자가 원하는 방향으로 변경할 수 있도록 도와줌
3. 제어문의 종류
	1) 조건문 : 특정한 조건을 만족하는 경우에 실행
		if(), switch()
	2) 반복문 : 특정한 조건을 만족할 때까지 반복 실행
		for, while, do-while
	3) break, continue : 조건문과 반복문을 제어
		- break : 실행중인 제어문을 완전히 종료
		- continue : 실행중인 제어문을 해당 횟수만 종료 -> 건너뛰기 느낌
4. 제어문의 중첩 - 제어문의 중괄호 내부에 또 다른 제어문 작성이 가능 (제어문을 제어하는 제어문)
*/

/*		
		int i = 0;
		System.out.println("i 실행 " + ++i + " line");
		System.out.println("i 실행 " + ++i + " line");
		System.out.println("i 실행 " + ++i + " line");
		System.out.println("i 실행 " + ++i + " line");
		System.out.println("i 실행 " + ++i + " line");
		System.out.println("i 실행 " + ++i + " line");
		System.out.println("i 실행 " + ++i + " line");
		System.out.println("i 실행 " + ++i + " line");
		System.out.println("i 실행 " + ++i + " line");
		System.out.println("i 실행 " + ++i + " line");
		
		for(int j = 0; j <= 10; j++) {
		System.out.println("j 실행 [" + j + "] line");
		}
*/		
		for (int k = 0; k <= 100; k++) {
			if (k == 83) {
				break;
			}
			if (k == 2) {
				continue;
			}
			if (k == 23) {
				continue;
			}
			System.out.println("for 실행 [" + k + "] line");
		}
	}

}
