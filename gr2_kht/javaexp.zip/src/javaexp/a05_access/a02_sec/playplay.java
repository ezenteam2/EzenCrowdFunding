package javaexp.a05_access.a02_sec;

import javaexp.a05_access.a02_sec.home.Mother;
import javaexp.a05_access.a02_sec.home.Father;

public class playplay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Mother m1 = new Mother();
		m1.whatFatherSays();

		Father f1 = new Father();
		f1.privateFather();
	}

}
