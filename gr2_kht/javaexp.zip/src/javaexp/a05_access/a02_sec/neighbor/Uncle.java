package javaexp.a05_access.a02_sec.neighbor;

public class Uncle {

}
