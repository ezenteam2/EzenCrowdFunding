package javaexp.a05_access.a02_sec.home;

import javaexp.a05_access.a02_sec.home.Father;

public class playplay02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Father f1 = new Father();
		f1.privateFather02();
		
	}

}
