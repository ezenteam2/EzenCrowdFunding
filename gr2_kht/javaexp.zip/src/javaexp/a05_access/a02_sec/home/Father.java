package javaexp.a05_access.a02_sec.home;

public class Father {

	String fatherSays = "엄마 어디써?";
	protected String fatherSays02 = "너한테만 하는 이야기인데";
	public String fatherSays03 = "엄마 완전 짱임";
	private String fatherSays04 = "아빠 비상금 벽장 속에 있음";
	
	public void privateFather () {
		System.out.println(fatherSays02);
	}
	
	void privateFather02 () {
		System.out.println(fatherSays04);
	}
}
