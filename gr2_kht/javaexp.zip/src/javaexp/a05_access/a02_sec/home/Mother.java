package javaexp.a05_access.a02_sec.home;

public class Mother {
	
	public void whatFatherSays() {
	Father f01 = new Father();
	//System.out.println(f01.fatherSays);
	//System.out.println(f01.fatherSays02);
	System.out.println(f01.fatherSays03);
	//System.out.println(f01.fatherSays04);
	
	}
}
