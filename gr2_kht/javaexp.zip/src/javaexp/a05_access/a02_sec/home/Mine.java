package javaexp.a05_access.a02_sec.home;

/*
ex)	private, default, public으로 접근 제어자 변수를 설정하고
	외부 클래스에서 호출하여 접근의 범위 확인
 */

public class Mine {


	}
