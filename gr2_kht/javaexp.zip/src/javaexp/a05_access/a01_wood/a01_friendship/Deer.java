package javaexp.a05_access.a01_wood.a01_friendship;

public class Deer {
	void callWoodInfo() {
		WoodCutter w1 = new WoodCutter();
		// Deer가 같은 package에 있으므로 접근이 가능..
		System.out.println("사슴을 숨긴 곳"+w1.cacheDeer);
		// 같은 package라도 private로 설정하면 접근을 할 수 없다.
//		System.out.println("천사 옷을 숨긴 곳"+w1.cacheClothe);
		// public은 같은 package의 클래스에서도 접근이 가능하다.
		System.out.println("장가 가는 날:"+w1.weddingDate);
	}
}
