package javaexp.a05_access.a01_wood;

import javaexp.a05_access.a01_wood.a01_friendship.WoodCutter;

public class Hunter {
	void callWoodInfo() {
		WoodCutter w1 = new WoodCutter();
		// Hunters는 같은 package가 아니므로 접근할 수 없다.
//		System.out.println("사슴을 숨긴 곳"+w1.cacheDeer);
		// private 설정된 변수는 class 내부에서만 접근이 가능하다.
//		System.out.println("천사 옷을 숨긴 곳"+w1.cacheClothe);
		// public 설정된 변수는 외부 class도 접근이 가능하다.
		System.out.println("장가 가는 날:"+w1.weddingDate);
	}
}
