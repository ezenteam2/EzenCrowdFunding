package javaexp.a05_access.a01_wood;

public class Wood {

}
