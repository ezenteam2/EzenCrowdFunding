package javaexp.a08_exception;

/*
# throws (예외 위임 - 떠넘기기)
	1. 자바의 경우, 메서드 단위의 예외를 해당 메서드로 다시 호출하는 곳으로 위임할 수 있다
	2. 장점 - try {} catch {} 블럭을 동일한 예외를 처리하는 곳에서 한꺼번에 처리할 수 있음
	3. 기본 형식
		1) 메서드 단위로 선언
			메서드명() throws 예외 클래스1, 예외 클래스2,
			ex)	public void call() throws ClassNotFoundException, NullPointerException {
					예외 발생할만한 코드에 의해 예외가 던져지면
				}
			ex)	public void call2() throws ClassNotFoundException, NullPointerException {
					예외 발생할만한 코드에 의해 예외가 던져지면
				}
			ex)	public void call3() throws ClassNotFoundException, NullPointerException {
					예외 발생할만한 코드에 의해 예외가 던져지면
				}
 													//throws가 없으면 각각의 메서드 안의 코드에 try / catch 를 사용해야 함
 			//	call, call2, call3을 호출하는 객체의 메서드 또는 Main()에서
 				try{
 					call();
 					call2();
 					call3();
 				} catch (classNotFoundException c) {
 				} catch (NullPointerException c) {
 				} catch (Exception c) {
 				} finally {
 				}
 				
 */

class ExceptionExp {
	public void findClass1() throws ClassNotFoundException {
		Class cls = Class.forName("java.lang.String2");
	}
	public void findClass2() throws ClassNotFoundException {
		Class cls = Class.forName("java.lang.String2");
	}
	public void findClass3() throws ClassNotFoundException {
		Class cls = Class.forName("java.lang.String2");
	}
}



public class A03_Throws {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ExceptionExp e = new ExceptionExp();
		
		try {
			e.findClass1();
			e.findClass2();
			e.findClass3();							// 메서드별로 더져진 예외의 내용을 한꺼번에 처리
		} catch (ClassNotFoundException e1) {
			//	e1.printStackTrace();
		} catch (Exception e2) {
			System.out.println(e2.getMessage());
		} finally {
			System.out.println("예외 / 비예외 상관 없이 처리할 코드는 여기에");
		}
		
		//ex)	Calcu 클래스에서 /0 ==> 연산 처리 입력한 2개의 값
		//		plus(), minus(), multi(), div() 에서 처리 하되 /0일 때 발생하는 예외와 기타 예외를 위임하여 처리
		
		Calcu cc01 = new Calcu();
		try {
			cc01.plus(1, 0);
			cc01.minus(1, 0);
			cc01.multi(1, 0);
			cc01.div(1, 0);
		} catch (ArithmeticException e3) {
			System.out.println(e3.getMessage());
		} finally {
			System.out.println("예외 / 비예외 상관 없이 처리할 코드는 여기에");
		}

	}

}

class Calcu {
	int first;
	int second;
	
	void plus (int first, int second) throws ArithmeticException {
		this.first = first;
		this.second = second;
		System.out.println(first + " + " + second + " = " + (first + second));
	}
	void minus (int first, int second) throws ArithmeticException {
		this.first = first;
		this.second = second;
		System.out.println(first + " - " + second + " = " + (first - second));
	}
	void multi (int first, int second) throws ArithmeticException {
		this.first = first;
		this.second = second;
		System.out.println(first + " * " + second + " = " + (first * second));
	}
	void div (int first, int second) throws ArithmeticException {
		this.first = first;
		this.second = second;
		System.out.println(first + " / " + second + " = " + (first / second));
	}
	
}
