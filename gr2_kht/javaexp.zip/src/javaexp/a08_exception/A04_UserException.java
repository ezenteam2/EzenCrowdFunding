package javaexp.a08_exception;

import java.util.Scanner;

/*
# 사용자 정의 예외
	1. 자바의 표준 API에서 제공하지 않는 개발자가 정의한 예외
	2. 개발자에 의해 정의된 애플리케이션 서비스와 관련된 예외
		ex) 네트워크 처리 예외, 잔고 부족, 특정조건에 대한 예외
	3. 기본 형식
		1) 선언
		class 사용자정의예외클래스 extends Exception||RuntimeException {
			생성자명 () {
			
			}
			생성자명 (String msg) {			//예외 처리시, 생성자를 통해서 특정한 문자열을 전달
				super (msg);			//e.getMessage()를 통하여 catch에서 처리할 내용을 기술
			}
		}
		2) 호출 시 처리
			try {
				if (조건)						//예외가 발생할 내용에 조건 처리
					throw new 사용자정의예외클래스("메세지");
			} catch ( 사용자정의예외클래스 e ) {
				e.getMessage();
			}
			
			
 */

class UserException extends Exception {

	public UserException (String msg) {
		super(msg);
	}
	
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		// 위에 선언된 생성자를 통해 super(msg)형태로 넘긴 msg를 getmessage()를 통해 받을 수 있음
	return "[사용자 정의 예외]" + super.getMessage();
		}
	
	public void show() {					//추가적인 기능 메서드도 처리 가능
			System.out.println("사용자 정의 예외의 메서드1 입니다");
	}

	
}

public class A04_UserException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for ( int cnt = 10; cnt >= 0; cnt--) {
			System.out.println("카운트 다운 : " + cnt);
			
			try {
			if (cnt == 0 ) {
				throw new UserException(cnt + "에서 예외 발생");
			}
			} catch (UserException e) {
				System.out.println("## 사용자 정의 예외 발생 ##");
				System.out.println(e.getMessage());
				e.show();
			}

		}
	
		//ex)	ID / PASS 지정된 내용과 다르게 입력되었을 때
		//		MemberException으로 사용자 정의 예외로 처리
		System.out.println();
		Scanner sc = new Scanner(System.in);
		System.out.println("ID를 입력하세요 : ");
		EnterID EI = new EnterID(sc.nextLine());
		try { 
		if ( !EI.ID.equals("himan")) {
			throw new IDChkException("아이디가 일치하지 않습니다");
		} else {
			EI.show();
		}
		} catch (IDChkException e2) {
			System.out.println("## 사용자 정의 예외 발생 ##");
			System.out.println(e2.getMessage());
			e2.show();
		}
				

	}
}	

	
class IDChkException extends Exception {

	public IDChkException (String msg) {
		super(msg);
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "[사용자 정의 예외]" + super.getMessage();
	}
	
	public void show() {
		System.out.println("ID가 일치하지 않습니다");
	}

}

class EnterID {
	
	String ID;
	public EnterID (String ID) {
		this.ID = ID;		
	}
	
	void show() {
		System.out.println("로그인 되었습니다");
	}
	
}