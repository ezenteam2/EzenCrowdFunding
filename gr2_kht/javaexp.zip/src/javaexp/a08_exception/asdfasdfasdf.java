package javaexp.a08_exception;

public class asdfasdfasdf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int tot = 0;
		
		for (int i = 150; i <= 10000 ; i++) {
			tot += i;			
		}
		
		int year = (int)(10000/365);
		System.out.println("10000일까지 : " + tot);
		System.out.println("10000일은 : " + year + "년");
		
		int tot2 = tot;
		double rate = 1.03;
		
		for (int i = 1; i <= year; i++) {
			tot2 = (int)(tot2 * rate);
		}
		
		System.out.println("5천만원은 " + year + "년 후 : " + tot2);
		
		

	}

}
