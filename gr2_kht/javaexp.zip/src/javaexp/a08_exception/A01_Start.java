package javaexp.a08_exception;

/*
# 예외 (Exception)
	1. 사용자의 잘못된 조작 또는 개발자의 잘못된 코딩으로 인한 오류
	2. 예외를 적절하게 처리함으로 프로그램의 안정성과 신뢰성을 확보할 수 있음
	3. 예외 처리 기본 형식
		try {
			예외 발생 가능성이 있는 코드
		} catch (Exception e) {
			예외가 발생했을 때, 처리할 코드 내용
		} finally {
			예외 발생 여부에 상관없이 처리할 코드
		}
	4. 예외 처리 프로세스
		1) 	예외 발생시, 해당 line에서 즉시, 예외 catch 블럭으로 던지고,
			예외 클래스를 받은 catch에서 예외 블럭에 처리
 */

public class A01_Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("처리1");
		System.out.println("처리2");
		try {
			System.out.println("예외 발생 가능성 코드1");
			System.out.println("예외 발생 가능성 코드2");
			System.out.println(4/0);
			System.out.println("예외 발생 가능성 코드3");
			System.out.println("예외 발생 가능성 코드4");
			System.out.println("예외 발생 가능성 코드5");
		} catch (Exception e) {
			System.out.println("예외발생");
			System.out.println(e.getMessage());
		} finally {
			System.out.println("예외 발생 여부 상관 없이 처리");
		}
		System.out.println("처리3");
		System.out.println("처리4");
		System.out.println("처리5");
		System.out.println("처리6");
		
	}

}
