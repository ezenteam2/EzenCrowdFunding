package javaexp.a08_exception;

/*
# 예외 처리 코드
	1. 	가능성 있는 예외 발생 코드를 직접 수행
	2. 	실행 결과로 발생한 예외 내용을 copy하여 
		catch( 예외 )로 선언
	3. 예외가 발생했을 때, 처리할 코드를 catch block에서 처리
 */

public class A02_ExceptionCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("수행 1");
		try {
			System.out.println(4/0);
		} catch (ArithmeticException ae) {
			System.out.println("예외 발생");
			System.out.println(ae.getMessage());
		}
		System.out.println("수행 3");
		System.out.println("수행 4");
		System.out.println("수행 5");
		
		//	ex) String name = null; System.out.println(name.toString());
		//	발생 예외 확인 후, 예외 처리
		
		System.out.println();
		
		String name = null;
		
		try {
			System.out.println(name.toString());
		} catch (NullPointerException aa) {
			System.out.println("똑바로 좀 하셈");
			System.out.println(aa.getMessage());
		}
		
		System.out.println();
/*		
		try {
			for ( int idx = 0; idx < 10; idx++  ) {
				System.out.println((idx+1) + "번째 과일 : " + args[idx]);
			}
		} catch (ArrayIndexOutOfBoundsException aiob) {
			System.out.println((aiob.getMessage()));
			System.out.println("배열 초과 예외 발생");
		} catch (Exception e) {								// 기타 예외에 대한 처리, catch로 구체적인 하위 예외를 처리한 후, 보다 넓은 예외를 처리한다
			System.out.println((e.getMessage()));
		} finally {											// 예외 상관 없이 처리할 내용은 finally를 통해 기술
				System.out.println("예외와 상관 없이 처리할 내용은 여기다가");
		}
			
		}
*/	
		//ex)	args[0] : id, args[1] password 인증여부 check
		//		입력값이 없을 때, 에외처리를 하여 경고 출력
		
		try {
			String id = args[0];
			String pass = args[1];
			if(id.equals("himan") && pass.contentEquals("7777"))
		
		
			System.out.println("ID : \t\t" + id.toString());
			System.out.println("PASSWORD : \t" + pass.toString());
		} catch (ArrayIndexOutOfBoundsException abcd) {
			System.out.println("입력값이 없습니다");
			System.out.println(abcd.getMessage());
		} finally {
			
		}
		
	}
}

