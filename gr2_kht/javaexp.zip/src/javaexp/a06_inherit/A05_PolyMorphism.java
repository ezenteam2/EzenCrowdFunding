package javaexp.a06_inherit;

/*
# 다형성
	1. 부모의 타입으로 같지만, 여러가지 상속한 다양한 객체 대입이 가능한 성질
		1) 부모 타입에는 모든 자식 객체가 대입 가능
		2) 자식 타입은 부모 타입으로 자동 타입 변환 (promote) 가능
			부모타입 참조 = new 자식타입();
			ex)	Cpu c1 = new Intel43Cpu();
				Cpu c2 = new Amd33Cpu();
		3) 객체를 부품화하여 효과적으로 할당 처리할 수 있음
			ex)	자동차 - 바퀴! 하나만 갈아끼워도 정상 작동! 다른 내부 기기는 손대지 않아도 댐
			
	2. 자동 타입 변환 (Promotion) (*작은 유형의 데이터를 큰 유형의 데이터로 할당할 때, 특별한 casting 과정이 필요 없음)
		1) 	상속관계에서도 데이터의 자동타입 변환과 같은 개념을 적용할 수 있음
		2) 	상위 클래스가 상속해 주는 객체는 메모리를 포함하여 더 큰 데이터 type으로 형성 되어,
			상속되는 하위 객체를 promote로 할당 가능
			ex)	Father f1 = new Son();
				Father f2 = new Daughter();
	
	3. 매개변수의 다형성
		1) 매개변수가 클래스 타입일 경우, 해당 상위 매개변수 객체로 하위 객체 대입이 가능하므로 여러 상속받은 객체를 할당 가능
 */

class Animal {
	private String kind;
	public Animal (String kind) {
		this.kind = kind;
	}
	public void sound () {
		System.out.println(kind +"이/가 소리를 지른다");
	}
	
}

class Cat extends Animal {

	public Cat () {
		super("고양이");
	}
	// 상속받은 하위 클래스는 상위 클래스의 생성자를 호출하여야 한다
	@Override
	public void sound() {
		// TODO Auto-generated method stub
		super.sound();
		System.out.println("야옹야옹");
	}	
	
}

class Panda extends Animal {

	public Panda () {
		super("판다");
	}
	// 상속받은 하위 클래스는 상위 클래스의 생성자를 호출하여야 한다
	@Override
	public void sound() {
		// TODO Auto-generated method stub
		super.sound();
		System.out.println("어떻게 우는지 아싐??? 들어 본적 있긔?");
	}	
	
}

class Lion extends Animal {

	public Lion () {
		super("사자");
	}
	@Override
	public void sound() {
		// TODO Auto-generated method stub
		super.sound();
		System.out.println("어흥어흥");
	}
	
}

class Zoo {
	String name;							// 할당 가능한 동물의 배열을 선언
	Animal[] animals;
	int addIdx;
	Zoo(String name, int cnt) {				// 입력값으로 배열의 갯수 설정
		animals = new Animal[cnt];			// 동물원의 이름 설정
		this.name = name;
	}
	public void addAnimal(Animal anim) {
		System.out.println("##### 동물원에 추가로 놀러온 동물");
		anim.sound();
		//현재 배열에 동물이 추가될 때마다 처리
		if( addIdx < animals.length ) {
		this.animals[addIdx++] = anim;
		} else {
			System.out.println("동물원이 가득차씁니다할");
		}
	}
	public void showAll() {
		System.out.println(name + "이 동물원에 있어용!!!");
		for (Animal an : animals) {
			if (an != null)
				an.sound();
		}
	}
}

public class A05_PolyMorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//ex1) 	상위 클래스 Animal, 재정의할 메서드는 sound()
		//		Cat, Lion을 상속, 해당 내용을 main()에서 promote 처리
		/*
		Animal animal01 = new Cat();
		Animal animal02 = new Lion();
		animal01.sound();
		animal02.sound();
		
		Animal animal03 = new Panda();
		animal03.sound();
		// 다양한 Animal 클래스를 상속받은 객체 할당 가능
		*/
		Zoo zoo01 = new Zoo("동물들이 행복한 동물원", 5);
		zoo01.addAnimal(new Lion());
		zoo01.addAnimal(new Cat());
		zoo01.addAnimal(new Panda());
		zoo01.showAll();
		
		
		
		/*
		Animal animals [] = {(new Cat()), (new Lion())};
		for (Animal animals01:animals) {
		animals01.sound();
		}
		*/
		/*
		Cat cat01 = (Cat) new Animal();
		Lion lion01 = (Lion) new Animal();
		cat01.sound();
		lion01.sound();
		*/
	}

}
