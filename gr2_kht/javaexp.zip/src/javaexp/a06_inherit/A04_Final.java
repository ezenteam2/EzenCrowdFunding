package javaexp.a06_inherit;

/*
# keyword "final"
	1. 필드명 앞에서	: 상수 - 한번 초기화 되면 변경할 수 없음
	2. class명 앞에서	: 상속이 불가능해 짐
	3. 메서드명 앞에서	: 하위 클래스에서 해당 메서드로 재정의(overriding) 불가
 */

class GrandFather{
	
	final String FAMILY;
	GrandFather() {
		FAMILY = "임씨네 집안!!";
	}									// final로 선언된 변수 name은 상수가 되어 다음부터 변경 불가
	final void showOurFamly() {			// final이 선언 되는 순간 26번 overriding 메서드에서 오류 발생
		System.out.println("할아버지 세대 우리 가계 : " + FAMILY);
	}
	
}

//	클래스명에 final이 선언되면, 하위클래스로 상속해줄 수 없음

final class Father01 extends GrandFather {		
	
	void showOurFamily() {
		System.out.println("우리 세대 우리 가계 : " + FAMILY);
	}
	
}

/*
class Son01 extends Father01 {
	
}
*/

public class A04_Final {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GrandFather gf = new GrandFather();
		System.out.println("할아버지 객체 : " + gf.FAMILY);
//		Son01 s01 = new Son01();
//		System.out.println("아들 객체 : " + s01.FAMILY);
		
		//s01.generation = "김씨네 집안"; 최상위 클래스에서 상수로 선언했으므로
		//				생성자를 받아, 초기화가 되고, final로 선언되었기때문에 변경되지 않음 

	}

}
