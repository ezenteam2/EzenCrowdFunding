package javaexp.a06_inherit;

import java.util.Scanner;

/*
# 상속
	1. 상위에서 하위로 물려주는 행위
	2. 객체지향 프로그래밍에서는 부모 클래스의 멤버를 자식 클래스에 물려 주는 것을 의미
		- 자식 클래스는 부모의 멤버를 접근제어자의 범위 안에서 사용가능
	3. 기본 형식
		class Father {
			String name;
			void call() {
				System.out.println(name + "야 이리 오너라");
			}
		}
		
		Class Son extends Father {
			int age;
			void call2() {
				call();
				System.out.println("니가 올 해로 벌써 " + age + "살이 되었구나");
			}	
		}
	4. 부모 생성자 호출 (super())
		1) 명시적 부모 생성자 호출
			- 부모 객체 생성시, 부모 생성자를 선택적으로 호출
				부모 class에서 여러 생성자를 선언할 수 있기 때문에
			- super(매개값)
				부모 생성자의 매개값에 맞게 선택하여 호출
			- 부모 생성자가 선언되지 않으면 컴파일 오류 발생
			- 반드시 자식 생성자의 첫 줄에 위치해야 함
 */

class Father {
	
//	public Father() {} 			=> default로 선언된 생성자 (생략)
	
	String name;
	
	Father (String name) {
		this.name = name;
	}							//	생성자를 생성하는 순간 하위 클래스에서 오류 발생 (46-48라인 없으면 Son 클래스 오류 발생)
	
	void call() {
		System.out.println(name + ", 이리 오너라");
	}
}

class Son extends Father {
	
//	public Son() { super() };	=> default로 선언된 생성자 (생략)
	
	public Son() {
		super ("아들");	
	}						// 상속받은 하위 클래스는 선언된 상위 생성자를 호출해야 함 (33-35라인 때문에 필요한 생성자)
	
	int age;
	void call2() {
		call();
		System.out.println("니가 올 해로 벌써 " + age + "살이 되었구나");
	}	
}	

/*
ex)	Computer, SamsunCom을 상속관계로 설정하고,
	Computer에는 공통적인 부분 (cpu, operation())
	SamsungCom 추가적인 멤버 (touchScreenMemory, touchScreen()) 
 */

class Computer {
	String cpu;
	Scanner sc01 = new Scanner(System.in);

	void operation() {
		System.out.print("CPU는 무엇? (A / B / C) : ");
		cpu = sc01.nextLine();
				
		for (int i = 0; i <= 10; i++) {
		if (cpu.equals("A")) {
			System.out.println("비싼거 고르셨네여");
			break;
		} else if (cpu.equals("B")) {
			System.out.println("조금 더 쓰지 그러셔써여");
			break;
		} else if (cpu.equals("C")) {
			System.out.println("똥컴이네여");
			break;
		} else {
			System.out.println("똑바로 입력하셈");
			System.out.print("CPU는 무엇? (A / B / C) : ");
			cpu = sc01.nextLine();
		}
		
		}
	}
}

class SamsungCom extends Computer {
	String touchScreenMemory;
	Scanner sc02 = new Scanner(System.in);
	
	void touchScreen () {
		operation();
		System.out.println();
		System.out.print("터치스크린메모리는 무엇? : ");
		touchScreenMemory = sc02.nextLine();
		System.out.println("뭐? 그게 " + touchScreenMemory + "라고??????" );
	}
}

	//ex) Worker 클래스 하위에 PoliceMan을 선언, Worker에서 매개변수가 있는 생성자를 선언하여, 하위 클래스에서 호출

class Worker {
	
	String worker01;
	
	Worker (String worker01) {
		this.worker01 = worker01;
		System.out.println(worker01 + "은/는 PoliceMan");
	}
	
}

class PoliceMan extends Worker {
	
	PoliceMan () {
		super ("포올리스맨");
	}
	void working() {
		System.out.println("나쁜 ShakeIt들을 잡아 쳐넣어 주십니다");
	}
}

class FireMan extends Worker {
	
	FireMan () {
		super ("퐈이얼맨");
	}
	void working() {
		System.out.println("퐈이어로부터 국민들의 생명을 지켜 주십니당");
	}
	
}

public class A01_Basic {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PoliceMan pm01 = new PoliceMan();
		pm01.working();
		
		System.out.println();
		
		FireMan fm01 = new FireMan();
		fm01.working();
		
		//다형성 : 상위클래스에 상속받은 여러 하위 객체를 할당하여, 상위클래스에서 다양한 형태를 모양으로 하위 객체화 되는 것
		Worker w1 = new PoliceMan();
		Worker w2 = new FireMan();
		Worker wk[] = {new PoliceMan(), new FireMan()};
		System.out.println("## 향상 for로 처리 ##");
		for(Worker w : wk) {
			w.working();
		}
		
		
		
		System.out.println();

		Son son01 = new Son();
		son01.name = "홍길동";	//Class Son에는 name이 없지만, Class Father를 상속받았기에 name을 사용할 수 있음
		son01.age = 150;
		son01.call2();
	
		System.out.println();
		
		SamsungCom ssc = new SamsungCom();
		ssc.touchScreen();
		
		
	}
	
	

}
