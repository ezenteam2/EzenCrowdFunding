package javaexp.a06_inherit;

abstract class Vehicle01 {
	public void speed01() {
		System.out.println("속도를 올려보는데 어디까지 올라갈진 모르겠고");
	}
	public abstract void driving();
}

class Car01 extends Vehicle01 {

	@Override
	public void driving() {
		// TODO Auto-generated method stub
		speed01();
		System.out.println("제로100 3초컷");
	}
	
}

class Trucker01 extends Vehicle01 {

	@Override
	public void driving() {
		// TODO Auto-generated method stub
		speed01();
		System.out.println("제로100 20초 컷 하지만 한번 열면 멈출 수 없어");
	}
	
}






abstract class AnimalABS {
	// 실제 메서드
	// 하위에 추상 메서드가 하나라도 있는 경우, 해당 메서드를 포함한 클래스는 추상 클래스이어야 함
	public void move() {
		System.out.println("움직인다핫");
	}
	public abstract void eat();		// 추상 매서드 선언
									// 하위에서 재정의할 메서드 선언
	
}

class Bird extends AnimalABS {		// 추상 클래스를 상속받는 클래스는 
									// 반드시 상위 클래스의 추상 메서드를 재정의 하여야 한다

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		move();	// 상위 클래스의 메서드를 사용
		System.out.println("새는 곤충을 잡아 먹는다고 하는데 꼭 그렇지는 않은 거 같고 음");
		
	}		 
	
}

public class A07_Abstract {

/*
# 추상 클래스
	1. 추상(abstract) :	실체들 간에 공통되는 특성을 추출한 것
							ex) 새, 곤충, 물고기 -> 동물(이라는 추상개념)
	2. 추상클래스 (abstract class)
		1)	실체 클래스들의 공통되는 필드와 메소드를 정의한 클래스
		2)	추상 클래스는 실체 클래스의 부모 클래스 역할 (단독 객체로서의 기능 불가)
		3)	실체 클래스가 아니기에 객체 생성을 할 수 없음 (	Animal an = new Animal(); (x)
												Animal an01 = new Bird(); (o)
												Animal an01 = new Fish(); (o)	=> 다형성으로 하위 클래스 구현	)
		4) 추상 메서드는 상속받는 하위 클래스에서 "반드시" 선언하여야 컴파일 됨 => 설계자 입장에서 메서드의 통일성을 유지할 수 있게하는 장치
	3. 기본 형식
	abstract Animal {
		하위 클래스들이 사용할 고통 메서드
		public void move () {
			@@@가 움직인다핫
		}
		abstract void eat ();	// 하위의 실제 클래스에서 재정의할 내용
	}
	class Bird extends Animal {
		public void eat () { 
			@@@는 곤충을 잡아 먹는다
		}
	}
	class Fish extends Animal {
		public void eat () {
			@@@는 뭘 먹지? 플랑크톤? 크릴 새우? 다른 물고기? 상어? 고래? 고뤠?
		}
	}
	
 */
	
		// ex) 	Vehicle - 추상 클래스,속도를 올리다(구상), driving() - 추상 메서드
		//		Car, Trucker 하위의 실체 클래스
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnimalABS abs01;			// 추상클래스 선언
//		abs01 = new AnimalABS();	// 실체가 없는 클래스이기때문에 추상클래스의 객체 생성 불가
		abs01 = new Bird();
		abs01.eat();				// 상위클래스가 하위클래스에서 다양한 형태로 만들어 지면서 재정의 됨
		System.out.println();
		Vehicle01 vc01 = new Car01();
		vc01.driving();
		Vehicle01 vc02 = new Trucker01();
		vc02.driving();

	}

}
