package javaexp.a06_inherit;

public class A02_Father {

	private String name;
	int age;
	protected String loc;
	public String announce;
	
}
