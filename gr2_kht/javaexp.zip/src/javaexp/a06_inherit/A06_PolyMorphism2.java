package javaexp.a06_inherit;

class Flyway {
	public int flyingTime;
	public void flying() {
		System.out.println("기본적인 움직임의 윙봉!!!!!!");
	}
}

class Wing01 extends Flyway {
	@Override
	public void flying() {
		// TODO Auto-generated method stub
		// super.flying();
		System.out.println("30분 날 수 있는 엔진 장착!!! 가즈아!!!!");
		super.flyingTime = flyingTime;
		flyingTime += 30;
		System.out.println(flyingTime + "분 날 수 있어영");
	}
}

class UpgradeWings02 extends Flyway {
	@Override
	public void flying() {
		// TODO Auto-generated method stub
		// super.flying();
		System.out.println("2시간 동안 날 수 있는 엔진 장착!!!! FLEX!!!!");
		super.flyingTime = flyingTime;
		flyingTime += 120;
		System.out.println(flyingTime + "분 날 수 있어영");
	}
}

class Robot {
	private Flyway fly;
	public void setFlyway(Flyway fly) {
		System.out.println("또봇이 날개 장착!!!!");
		this.fly = fly;
	}
	public void rbflying() {
		System.out.println("또봇!!!");
		if ( fly != null ) {
			fly.flying();
		} else {
			System.out.println("날개를 장착해 주세여");
		}
	}
}

public class A06_PolyMorphism2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Robot r01 = new Robot();
		r01.rbflying();
		r01.setFlyway(new Wing01());
		r01.rbflying();
		r01.setFlyway(new UpgradeWings02());
		r01.rbflying();
	}

}
