package javaexp.a06_inherit.access;

import javaexp.a06_inherit.A02_Father;

public class Uncle {

	void callFatherInfo() {
		A02_Father f = new A02_Father();
//		f.name = "아들1";			=> private	: 접근 불가
//		f.age = 30;					=> default	: 접근 불가
//		f.loc = "서울 강남";		//	=> 상속관계에서만 접근 가능
		f.announce = "SNS 로딩 공개 자료!";
	}
}
