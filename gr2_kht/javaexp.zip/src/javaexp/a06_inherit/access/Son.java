package javaexp.a06_inherit.access;

import javaexp.a06_inherit.A02_Father;

public class Son extends A02_Father {

	void callFatherInfo() {
//		name = "Son1";				=> private	: 접근 불가
//		age = 30;					=> default	: 접근 불가
		loc = "Gannam Style";				//	=> 접근 가능
		announce = "OBBAN GANGNAM STYLE";	//	=> 접근 가능 
		
	}
}
