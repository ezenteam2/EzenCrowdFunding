package javaexp.a06_inherit;

/*
# 메서드 재정의 (Overriding)
	1. 부모 클래스의 상속 메서드를 수정해 자식 클래스에서 재정의 하는 과정
		- 상속 받은 매서드를 자식 클래스에 맞는 다양한 내용으로 선언하기 위해 사용
	2. 매서드 재정의 조건
		1) 부모 클래스의 메서드와 메소드명이 동일
		2) 접근 제한을 더 강하게 선언할 수 없음 (같거나 더 넓은 범위로)
			- 상위에서 public으로 선언한 메소드를 하위에서 default, private로 선언할 수 없음
		3) 새로운 예외(Exception)을 throws(예외 위힘)할 수 음슴
 */


	//ex) 	상위클래스 Fruit, 하위 클래스 Strawberry, Apple
	//		taste()를 재정의(overriding)

class Fruit{
	String fruit01;
	public Fruit(String fruit01) {
		this.fruit01 = fruit01;
	}
	public void taste() {
		//this.fruit01 = fruit01;
		System.out.println(fruit01 + "은 달다하앍");
	}
}

class Strawberry extends Fruit {
	
	public Strawberry() {
		super("딸기");		
	}
	
	public void taste() {
		super.taste();
		System.out.println(fruit01 + "은 빨갛고 달고 새콤달콤 스트로베리맛");
		System.out.println(fruit01 + "은 결국 과일이지");
	}
	
	public void callOther() {
		// 현재 메서드 호출.
		this.taste();
	
		// 상위 메서드 호출.
		super.taste();
	}
}

class Apple extends Fruit {
	public Apple() {
		super("사아과");
	}
	public void taste() {
		super.taste();
		System.out.println("사과도 빨갛고 달고 새콤달콤 사과맛인데 시큼시큼 청사과 마시게따");
	}
	
}

public class A03_Overriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Fruit fr01 = new Fruit("과아일");
		Strawberry sb01 = new Strawberry();
		Apple ap01 = new Apple();
		
		fr01.taste();
		System.out.println();
		sb01.taste();
		System.out.println();
		ap01.taste();

	}

}
