package javaexp.a06_inherit;

/*
# 인터페이스
1. 개발 코드와 객체가 서로 통신하는 접점
2. 개발 코드는 인터페이스의 메소드만 알고 있다면 오케이
3. 역할	- 개발 코드가 객체에 종속되지 않게 하여 객체 교체를 수월하게 해주는 역할
		- 개발 코드의 변경 없이 리턴값 또는 실행 내용을 다양하게 설정할 수 있게 함
4. 인터페이스 선언	1)	자바 식별자 작성 규칙에 따라 작성
				2)	형식 :	interface 인터페이스명{
								멤버
							}
				3)	구성 멤버	- 인터페이스의 필드는 모두 상수(public static final)로 할당
								ex) (interface에서) int NUM01 = 5; == static final int NUM01 = 5;
							- 선언된 메서드는 모두 추상 메서드
								ex) (interface에서) void call();	==	public abstract void call();
							- default 리턴타입 메서드명 (매개변수);
								ex)	default void show (String msg) {
										System.out.println ("출력할 메서드 " + msg);
									}
							- 정적 메서드
								static 타입 메서드명 (매개변수) {
								}
				4) 실제 클래스 상속 - interface는 implements가 상속한다
					ex)	class 실제클래스 implements 인터페이스{
							//	선언한 추상메서드는 반드시 재정의 하여야 한다 
						}
*/

interface Wings {
	void flying();	// == public abstract void flying();
}

class Wings01 implements Wings {

	@Override
	public void flying() {
		// TODO Auto-generated method stub
		System.out.println("날개 1호를 달고 우리 동네 정도만 돌아다닐수 있긔");
	}
	
}

class Wings02 implements Wings {
	
	@Override
	public void flying() {
		// TODO Auto-generated method stub
		System.out.println("날개 2호를 달고 씨티 정도를 날아다닐 수 있긔");
	}
	
}

class Wings03 implements Wings {
	
	@Override
	public void flying() {
		// TODO Auto-generated method stub
		System.out.println("날개 3호 달고 제주도 정도까지 갈수 있긔");
	}
	
}

class MZ {
	// 인터페이스를 중앙 controller에서 사용할 수 있게 메모리 선언
	private Wings wing;
	public void attack() {
		System.out.println("MZ 어태킈!!!!!!!!");
	}
	// 매개변수로 상위 인터페이스를 선언하여, 상속받는 여러 하위 객체를 할당할 수 있게 함
	public void addWings(Wings wing) {
		this.wing = wing;
	}
	
	public void FTTS() {
		System.out.println("MZ는 ~~~~~~~~~~~~~~");
		if (wing != null) {
			wing.flying();
		} else {
			System.out.println("날개부터 장착하거라 닝겐");
		}
	}
}

public class A08_Interface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MZ mz01 = new MZ();
		mz01.attack();
		mz01.FTTS();
		System.out.println();
		
		mz01.attack();
		mz01.addWings(new Wings01());
		mz01.FTTS();
		System.out.println();

		mz01.attack();
		mz01.addWings(new Wings02());
		mz01.FTTS();
		System.out.println();
		
		mz01.attack();
		mz01.addWings(new Wings03());
		mz01.FTTS();
		System.out.println();
		
		
		//ex)	SoundWay 인터페이스 sound()
		//		하위 클래스 : 꽥꽥거리다 / 소리가 없다 / 삑삑 전자음
		//		Duck02에서 해당 인터페이스 처리
		
		
		Duck02 DK02 = new Duck02();	
		DK02.cryCryCry();
		DK02.shoutItOut();
		System.out.println();
		
		DK02.cryCryCry();
		DK02.addCryingSound(new Quack01());
		DK02.shoutItOut();
		System.out.println();
	
	}
	
	

}

interface SoundWay {
	void sound();
}

class Quack01 implements SoundWay {

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("꽥꽥꽦꽦꼬ㅒㄲ꽤꽤꽦꼬ㅒㄲ꼬ㅒ꽤꽤괘");
		
	}
	
}

class Mute implements SoundWay {
	
	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("(조요오오오오오오오오오옹)");
		
	}
	
}

class Beep01 implements SoundWay {
	
	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("삐이~~~~~~~~~~~~~~~~~");
		
	}
}
	
class Duck02 {
	private SoundWay sw;
	public void cryCryCry() {
		System.out.println("오리가 소리를 냅니다");
	}
	
	public void addCryingSound (SoundWay sw) {
		this.sw = sw;
	}
	
	public void shoutItOut () {
		System.out.println("오리는 ");
		if (sw != null) {
			sw.sound();
		} else {
			System.out.println("뭐라고 울어볼까여?");
		}
	}
	
}

	

