package HOMEWORK;

// Paint 인터페이스에 drawing() 추상 메서드를 선언, CirclePaint, SquarePaint, TraianPaint 선언 후 호출

interface painting {
	void drawing();
}

class CirclePaint implements painting {
	public void drawing() {
		System.out.println("○●○●○ 동그라미를 그려봅시다");
	}
}

class SquarePaint implements painting {
	public void drawing() {
		System.out.println("□■□■□ 네모를 그려봅시다");
	}
}

class TrianPaint implements painting {
	public void drawing() {
		System.out.println("△▲△▲△ 세모를 그려봅시다");
	}
}

class paintingWhat {
	painting paint;
	public void start() {
		System.out.println("그림을 그려봅시다");
	}
	
	public void addPainting (painting paint) {
		this.paint = paint;
	}
	
	public void mainPainting () {
		if ( paint != null ) {
			paint.drawing();
		} else {
			System.out.println("뭘 그려보싈?");
		}
	}
}

public class b0106_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		paintingWhat pw = new paintingWhat();
		pw.start();
		pw.addPainting(new SquarePaint());
		pw.mainPainting();

	}

}
