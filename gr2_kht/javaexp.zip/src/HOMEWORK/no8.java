package HOMEWORK;

public class no8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int date = 1;
		int food = 6000;
		int foodTot = 0;
		int pockerMoney = 10000;
		int pocketMoneyTot = 0;
		int balance = 0;

		System.out.println((date++) + "일 \t 식비누적 " + (foodTot += food)
				+ "\t 용돈 " + (pocketMoneyTot += pockerMoney) 
				+ "\t 현잔액 " + (balance + pocketMoneyTot - foodTot));
		System.out.println((date++) + "일 \t 식비누적 " + (foodTot += food) 
				+ "\t 용돈 " + (pocketMoneyTot += pockerMoney) 
				+ "\t 현잔액 " + (balance + pocketMoneyTot - foodTot));
		System.out.println((date++) + "일 \t 식비누적 " 
				+ (foodTot += food) + "\t 용돈 " + (pocketMoneyTot += pockerMoney) 
				+ "\t 현잔액 " + (balance + pocketMoneyTot - foodTot));
	}

}
