package HOMEWORK;

import java.util.Scanner;

public class no12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc01 = new Scanner(System.in);
		System.out.print("시작 단수 : ");
		int startNo = sc01.nextInt();
		System.out.print("끝 단수 : ");
		int finishNo = sc01.nextInt();

		for (int idx01 = startNo; idx01 <= finishNo; idx01++) {
		System.out.println(idx01 + "단");
		for (int idx = 1; idx <= 9; idx++) {
		System.out.println(idx01 + " * " + idx + " = " + (idx01 * idx));
		}
		}
	}

}
