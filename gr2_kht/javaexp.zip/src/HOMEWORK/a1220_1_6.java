package HOMEWORK;

public class a1220_1_6 {

	/*
	6. 학생 100명의 컴퓨터 개론 점수을 0~100로 임의로 할당하고,
	int[] points = new int[100]; 
	학생100명의 평균점수, 최대점수, 최소점수를 출력 처리하세요
	*/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		System.out.println("100명 임의의 점수 할당");
		
		int [] point = new int[100];
		int max = 0;
		int min = 100;
		int tot = 0;
		
		for ( int i = 0; i < point.length; i++ ) {
		point[i] = (int)(Math.random() * 101);
		System.out.print(point[i] + "\t");
		if (point[i] > max) {
			max = point[i];
		}
		if (point[i] < min) {
			min = point[i];
		}
		tot = tot + point[i];
		}
		
		System.out.println();
		System.out.println("총점 : " + tot);
		System.out.println("평점 : " + (tot / 100));
		System.out.println("Maximum : " + max);
		System.out.println("Minimum : " + min);


	}

}
