package HOMEWORK;

public class a1220_2_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int no01 = 500;
		while ( no01 <= 10 ) {
			System.out.println(no01 + "번째 실행");
			no01++;
			}
		
		int no02 = 300;
		do {
			System.out.println(no02 + "번째 실행");
		} while (no02 <= 10);
	}

}
