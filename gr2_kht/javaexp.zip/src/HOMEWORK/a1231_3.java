package HOMEWORK;

/*
상위 클래스 Draw, drawing()이라는 메서드를 정의
삼각형 그리기, 사각형 그리기, 원 그리기의 하위 클래스에 drawing()을 선언하고 overriding 처리
상속 및 재정의 처리내용을 main()를 통해 구현
*/


public class a1231_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
