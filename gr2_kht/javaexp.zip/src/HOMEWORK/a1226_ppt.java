package HOMEWORK;

public class a1226_ppt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String mark[] = {"♣", "♥", "◆", "♠"};
		String num[] = {"2", "3", "4", "5", "6", "7", "8", "9", "J", "Q", "K", "A"};
		String trump[] = new String[mark.length * num.length];
		int i = 0;		

		for (int numIdx = 0; numIdx < num.length; numIdx++) {			

			for (int markIdx = 0; markIdx < mark.length; markIdx++) {				

				trump[i] = mark[markIdx] + num[numIdx];
				//System.out.println(trump[i]);
				i++;			

			}			

		}

		

		String person [] = new String[7];
		int winner [] = new int[2];		

		for (int personNum = 0; personNum < 2; personNum++) {
			System.out.println((personNum+1) + "번째 사람의 카드");			

			for (int ranChoice = 0; ranChoice <= 6; ranChoice++) {			

				int ranNum = (int)(Math.random() * (mark.length * num.length));
				person [ranChoice] = trump [ranNum];			

					for (int repeatChk = 0; repeatChk < ranChoice; repeatChk++) {
						if (person[repeatChk].equals(person[ranChoice])) {
							ranChoice--;
						}					

					}			

				System.out.println((ranChoice + 1) + "번째 카드 : \t" + trump[ranNum]);				

				if (winner[personNum] < ranNum) {
					winner[personNum] = ranNum;
				}				

			}

			System.out.println((personNum + 1) + "번째 사람의 가장 높은 카드 : " + trump[winner[personNum]]);
			System.out.println();		

		}		

		if (winner[0] > winner[1]) {
			System.out.println("1번째 사람이 이겼습니다!!!!!!!!");
		} else {
			System.out.println("2번째 사람이 이겼네용?!?!?!?!?!?");
		}
	
	}

}
