package HOMEWORK;

import java.util.Scanner;

public class a1220_2_4 {

/*
4. Scanner를 이용하여 시작할 단수, 종료할 단수를 입력 받아서
	### @@단 ## ### @@단 ## ### @@단 ##
	형식으로 구구단의 특정 시작과 마지막 단수를 출력 처리하세요.
 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc01 = new Scanner(System.in);
		Scanner sc02 = new Scanner(System.in);
		
		System.out.print("시작할 구구단 단수 : ");
		int firstNo = sc01.nextInt();
		System.out.print("마지막 구구단 단수 : ");
		int lastNo = sc02.nextInt();
		
		for (int j = firstNo; j <= lastNo; j++) {
		System.out.println(firstNo +"단 시작!!!!!");
		for (int i = 1; i <= 9; i++) {
			System.out.println(firstNo + " * " + i + " = " + (firstNo * i));
		}
		firstNo++;
		System.out.println();
		}
	}

}
