package HOMEWORK;

import java.util.Scanner;

public class a1220_1_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.print("나이는 ? ");
		
		String abc [] = {"원숭이", "닭", "개", "돼지", "쥐", "소", "호랑이", "토끼", "용", "뱀", "말", "양"};
		String cdf [] = {"신", "유", "술", "해", "자", "축", "인", "묘", "진", "사", "오", "미"};
		
		int age = sc.nextInt();
		int ageX = age % 12;
		switch ( ageX ) {
		case 0 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		case 1 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		case 2 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		case 3 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		case 4 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		case 5 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		case 6 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		case 7 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		case 8 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		case 9 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		case 10 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		case 11 :
			System.out.println("\"" + abc[ageX] + "\"띠네여? 12간지는 \"" + cdf[ageX] + "\"");
			break;
		default :
			System.out.println("똑바로 입력하셈");
		}		
				

	}

}
