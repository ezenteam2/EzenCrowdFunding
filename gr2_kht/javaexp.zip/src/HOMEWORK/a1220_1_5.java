package HOMEWORK;

public class a1220_1_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("3 6 9 시작!!!");
		for ( int startNo = 1; startNo <= 50; startNo++ ) {
		int ten = startNo % 10;
		int three = ten % 3;
		
		if (startNo > 10 && three == 0) {
			System.out.println("짝");
		} else {
		
		switch (ten) {
		case 0 :
			System.out.println(startNo);
			break;
		default :
		
				
		switch ( three ) {
		case 1 :
			System.out.println(startNo);
			break;
		case 2 :
			System.out.println(startNo);
			break;
		default :
			System.out.println("짝!");
		}
		}
		
		}
		}
		
	}

}
