package HOMEWORK;

public class a1223_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int oddNumSum = 0;
		int evenNumSum = 0;
		int sum = 0;
		for ( int no = 1; no <= 100; no++) {
			sum += no;
			if ( no % 2 == 1 ) {
				oddNumSum += no;
			} else {
				evenNumSum += no;
			}
		}
		System.out.println("1 ~ 100 사이 홀수의 총합 : " + oddNumSum);
		System.out.println("1 ~ 100 사이 짝수의 총합 : " + evenNumSum);
		System.out.println("1 ~ 100 사이 수의 총합 : " + sum);

	}

}
