package HOMEWORK;

public class a1224_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
 	쇼핑몰에 산 물건의 가격과 개수 를 2중 배열로 선언하고, 총 비용을 계산
	3000 3 5000 5 12000 3
 */
	
	int shopping [][] = {{3000, 3}, {5000, 5}, {12000, 3}};
	int sum = 0;
	int price = 0;
	
	for ( int idx = 0; idx < shopping.length; idx++ ) {;
	
	price = shopping[idx][0] * shopping[idx][1];
	sum += price;
	
	}
	
	System.out.println("총 가격 : " + price);
	
	}
	
	

}
