package HOMEWORK;

class Car {
	
	Tire frontLeftTire = new Tire("앞왼쪽");
	Tire frontRightTire = new Tire("앞오른쪽");
	Tire backLeftTire = new Tire("뒤왼쪽");
	Tire backRightTire = new Tire("뒤오른쪽");
	
}


class Tire {
	public String location;
	public Tire(String location) {
		this.location = location;
	}	
}

class HKTire extends Tire {
	
	
	HKTire (String location) {
		super(location);
		System.out.println(location + "에 한국타이어가 장착되었습니다.");
	}
	
	
	
	
}



public class PolyMorphismExample_Tire {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Car car01 = new Car();
		

	}

}
