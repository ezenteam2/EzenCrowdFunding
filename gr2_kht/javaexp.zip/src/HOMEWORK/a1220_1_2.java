package HOMEWORK;

public class a1220_1_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String mark[] = {"◆", "♠", "♥", "♣"};
		String num[] = {"A", "1", "2", "3", "4", "5", "6", "7", "8", "9", "J", "Q", "K"};
		
		int ranMark01 = (int)(Math.random() * mark.length);
		int ranNum01 = (int)(Math.random() * num.length);
		
		System.out.println("뽑은 카드는 ? " + mark[ranMark01] + num[ranNum01]);
		
		int ranMark02 = (int)(Math.random() * mark.length);
		int ranNum02 = (int)(Math.random() * num.length);
		
		System.out.println("뽑은 카드는 ? " + mark[ranMark02] + num[ranNum02]);
		System.out.println();
		
		

	}

}
