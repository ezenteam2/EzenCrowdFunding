package HOMEWORK;

import java.util.Scanner;

public class a1223_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		String IDDD = "idbabo";
		String PASWORDDD = "abcdefg";
		
		System.out.print("ID를 입력하세요 : ");
		String id = sc.next();
		System.out.print("PASSWORD를 입력하세요 : ");
		String password = sc.next();
		
		if ( id.equals(IDDD) && password.equals(PASWORDDD) ) {
			System.out.println("다 맞추셨네영 로긴!!!!");			
		} else if ( id.equals(IDDD) && !password.equals(PASWORDDD) ) {
			System.out.println("PASSWORD를 잘못 입력하셨습니다");
		} else if ( !id.equals(IDDD) && password.equals(PASWORDDD) ){
			System.out.println("ID 또는 PASSWORD를 확인 하세요");
		} else {
			System.out.println("아는게 뭐임?");
		}

	}

}
