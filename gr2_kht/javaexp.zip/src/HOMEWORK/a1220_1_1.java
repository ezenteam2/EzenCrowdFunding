package HOMEWORK;

import java.util.Scanner;

public class a1220_1_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String game1[] = {"가위", "바위", "보"};
		int cIdx = (int)(Math.random() * game1.length);
		String comCh = game1[cIdx];
		Scanner sc = new Scanner(System.in);
		System.out.print("가위(1) 바위(2) 보(3) 선택하세용 : ");
		int huIdx = sc.nextInt() - 1;
		System.out.println("사아람 : " + game1[huIdx]);
		System.out.println("컴퓨터 : " + comCh);
				
	}

}
