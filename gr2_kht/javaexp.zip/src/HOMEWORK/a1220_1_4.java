package HOMEWORK;

public class a1220_1_4 {

	
	/*
	4. for문을 이용해서 카드 7장씩, 컴퓨터와 1:1로 게임하기.
	나 : ♥4, ...
	컴퓨터 : @@@.....
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String mark[] = {"◆", "♠", "♥", "♣"};
		String num[] = {"A", "1", "2", "3", "4", "5", "6", "7", "8", "9", "J", "Q", "K"};
		String chCards[] = new String[52];
		int cIdx = 0;
		for ( int idx = 0; idx < mark.length; idx++) {
			for( int jdx = 0; jdx < num.length; jdx++) {
				chCards[cIdx] = mark[idx] + num[jdx];
				System.out.print(chCards[cIdx] + "\t");
				cIdx++;
			}
			System.out.println();
		}
		
		System.out.println();
		
		System.out.print("내 카드 : \t\t");
		for (int cnt = 1; cnt <= 7; cnt++) {
			int rIdx = (int)(Math.random() * chCards.length);
			System.out.print(chCards[rIdx] + "\t");
		}
		
		System.out.println();
		
		System.out.print("컴퓨터 카드 : \t");
		for (int cnt = 1; cnt <= 7; cnt++) {
			int rIdx = (int)(Math.random() * chCards.length);
			System.out.print(chCards[rIdx] + "\t");
		}
		
	}

}
