package HOMEWORK;

import java.util.Scanner;

public class a1220_1_7 {

	/*
	7. while문을 이용해서 1~1000 사이의 임의의 번호 맞추기.
	@@ 회째 시도 몇번일까요? 
	맞추는 @@회로 정답 성공..
	*/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int ranNo = (int)(Math.random() * 100);
		System.out.print("숫자를 입력해보셈 : ");
		int choiceNo = sc.nextInt();
		int i = 1;
		
		while (choiceNo != ranNo ) {
		if ( choiceNo > ranNo ) {
			System.out.println("더 작은 숫자입니다");
			System.out.print("더 작은 숫자를 입력하세요 : ");
			int choiceNo01 = sc.nextInt();
			choiceNo = choiceNo01;
			i++;
		} else {
			System.out.println("더 큰 숫자입니다");
			System.out.print("더 큰 숫자를 입력하세요 : ");
			int choiceNo01 = sc.nextInt();
			choiceNo = choiceNo01;
			i++;
		}  
			
			
		} 
			
		System.out.println("정답입니다!!!!!");
		System.out.println(i + "회만에 성공!!!!");
		}
	
}
