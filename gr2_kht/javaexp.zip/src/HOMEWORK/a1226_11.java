package HOMEWORK;

public class a1226_11 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		class Product{
			String name;
			int price;
			int cnt;
			Product(String name, int price, int cnt){
				this.name = name;
				this.price = price;
				this.cnt = cnt;
			}
			void show() {
				System.out.print(name+"\t");
				System.out.print(price+"\t");
				System.out.print(cnt+"\n");
			}
		}
		class Mart{
			String name;
			Product p;
			Mart(String name){
				this.name = name;
			}
			// Prouduct p = new Product("사과",3000,2);
			void buy(Product p) {
				this.p=p;
			}
			void showCart() {
				System.out.println(name+"에 가서 산 물건");
				if(p != null) {
					p.show();
				}else {
					System.out.println("구매한 물건이 없습니다.");
				}
			}
		}
		
	}

}
