package HOMEWORK;

class Computer {
	Computer (String computerName) {
		System.out.println("컴퓨터 이름은 : " + computerName);
	}
}



public class a1231_team {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
