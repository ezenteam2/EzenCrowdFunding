package HOMEWORK;

class Tire01 {
	String kind;
	public Tire01(String kind) {
		super();
		this.kind = kind;		
	}
	//재정의할 메서드 선언
	public void driving() {
		System.out.println(kind + "타이어 장착");
	}
}

class HKTire01 extends Tire01 {
	// 반드시 상위에 선언한 생성자를 호출
	public HKTire01() {
	super("한국");
	}
	//상위 메서드 재정의

	@Override
	public void driving() {
		// TODO Auto-generated method stub
		super.driving();
		System.out.println("안정성이 +10 되었습니다.");
		System.out.println("민첩성이 -10 되었습니다");
	}
	
}

class GHTire01 extends Tire01 {
	public GHTire01() {
		super("금호");
	}

	@Override
	public void driving() {
		// TODO Auto-generated method stub
		super.driving();
		System.out.println("민첩성이 +10 되었습니다");
		System.out.println("안정성이 -10 되었습니다");
	}
	
}

class Car01 {
	private String kind;
	private Tire01 [] tires;
	public Car01(String kind) {
		super();
		this.kind = kind;
		// 초기 Tire 배열 만들어서 타이어를 장착할 수 있도록 설정
		tires = new Tire01[4];
	}
	// 타이어 위치와 해당 객체를 할당할 수 있는 메서드 정의
	// setTire(타이어객체, 1~4)
	// Tire tire = new HKTire01();
	// Tire의 하위 객체로 상속한 모든 Tire는 다형성에 의해 할당
	// 추가 Tire적인 Tire는 상속만 하면 할당 가능
	public void setTire(Tire01 tire, int position) {
		// 0 ~ 3 index 기준으로 tire 장착
		tires[position - 1] = tire; 
	}
	public void showTires() {
		//각각의 위치를 표기하기 위한 문자열 처리
		String [] posStr = {"앞왼쪽", "앞오른쪽", "뒤왼쪽", "뒤오른쪽"};
		System.out.println("##" + kind + "의 타이어들 ##");
		for (int idx = 0; idx < tires.length; idx ++) {
			System.out.println("#" + (idx + 1) + " 번째 타이어 위치 : " + posStr[idx]);
			System.out.println("위치 : " + posStr[idx]);
			tires[idx].driving();
		}
	}
}


public class PolyMorphismExample_Tire_Teacher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car01 c1 = new Car01("Ferrari");
		c1.setTire(new HKTire01(), 1);
		c1.setTire(new GHTire01(), 2);
		c1.setTire(new HKTire01(), 3);
		c1.setTire(new GHTire01(), 4);
		c1.showTires();
	}

}
