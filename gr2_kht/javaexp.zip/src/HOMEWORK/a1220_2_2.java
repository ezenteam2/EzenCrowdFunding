package HOMEWORK;

import java.util.Scanner;

public class a1220_2_2 {

/*
2. switch case "문자열"인식 을 이용하여 
	입력한 등급에 따른 설명 출력 Scanner 클래스   
	ex) 확인할 등급 : "A"
	A학점은  90~100 점 사이입니다.
	B학점은  80~90 점 사이입니다.
    ..
    F..
      그 외에는 등급 A~F까지만 인식할 수 있습니다.
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		System.out.print("확인 등급 : ");
		String input = sc.nextLine();
		switch (input) {
		case "A" :
			System.out.println("A학점은 90~100점 사이입니다");
			break;
		case "B" :
			System.out.println("B학점은 80~90점 사이입니다");
			break;
		case "C" :
			System.out.println("C학점은 70~80점 사이입니다");
			break;
		case "D" :
			System.out.println("D학점은 60~70점 사이입니다");
			break;			
		case "F" :
			System.out.println("F학점은 60점 이하입니다");
			break;
		default :
			System.out.println("A, B, C, D, F만 입력 가능합니다.");
		}
	}

}
