package HOMEWORK;

public class a1224_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String product[] = {"T-Shirts", "30000", "5"};
		for ( int idx = 0; idx < product.length; idx++ ) {
	
			if ( idx == 0 ) {
				System.out.println("Product name : " + product[0]);
			} else if ( idx == 1 ) {
				System.out.println("Product price : " + product[1]);
			} else {
				System.out.println("Product number : " + product[2]);
			}
	

	}

	}
}
