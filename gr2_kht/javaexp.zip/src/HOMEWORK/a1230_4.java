package HOMEWORK;

import java.util.Scanner;

class Vehicle {
	
	String kind;
	void driving() {
		System.out.println(kind+"를 타보았다");
	}
	
}

class Car extends Vehicle {
	
	
	Car(){
		Scanner sc = new Scanner(System.in);
		System.out.print("탈 것의 종류를 입력하세여 : ");
		kind = sc.nextLine();
		driving();
	}
	int speed;
	void speedUp() {
		System.out.println(kind +"를 더 빠르겤ㅋㅋㅋㅋㅋ");
		speed += 10;
		System.out.println(kind + "의 현재속도는" + speed + "km/h");
	}
	
}

public class a1230_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Car car01 = new Car();
	car01.speedUp();
	

	}

}
